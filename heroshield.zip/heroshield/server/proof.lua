-- Screenshots, ban proof (shots + replay), image upload and Discord embeds
local pending = {}    -- [banId] = proof in progress
local captures = {}   -- [id] = screenshot asked to a client
local nextId = 0

local function normalize(d)
    if type(d) ~= 'string' or #d < 100 then return nil end
    if d:sub(1, 5) ~= 'data:' then d = 'data:image/jpeg;base64,' .. d end
    return d
end

local function urlencode(s)
    return (s:gsub('[^%w%-_%.~]', function(c) return ('%%%02X'):format(c:byte()) end))
end

function HS.screenshotResource()
    local r = Config.Screenshot.Resource
    if r == 'auto' then
        if GetResourceState('screencapture') == 'started' then return 'screencapture' end
        if GetResourceState('screenshot-basic') == 'started' then return 'screenshot-basic' end
        return nil
    end
    return GetResourceState(r) == 'started' and r or nil
end

function HS.siteUrl()
    local base = HS.baseUrl and HS.baseUrl() or ''
    return (base:gsub('/api$', ''))
end

local function clientCapture(src, cb)
    if GetResourceState('screenshot-basic') ~= 'started' then return cb(nil, 'screenshot-basic not started') end

    -- official screenshot-basic server export (returns a data URI when no fileName is given)
    local answered = false
    local ok = pcall(function()
        exports['screenshot-basic']:requestClientScreenshot(src, { encoding = 'jpg', quality = Config.Screenshot.Quality },
            function(err, data)
                if answered then return end
                answered = true
                if err or not normalize(data) then return cb(nil, 'screenshot-basic: ' .. tostring(err or 'empty image')) end
                cb(normalize(data))
            end)
    end)
    if ok then
        SetTimeout(8000, function()
            if not answered then answered = true cb(nil, 'screenshot-basic: no answer from the player (game minimized?)') end
        end)
        return
    end

    -- fallback: our own client code
    nextId = nextId + 1
    local id = tostring(nextId)
    local done = false
    captures[id] = { src = src, cb = function(d)
        if done then return end
        done = true
        captures[id] = nil
        cb(normalize(d), d and nil or 'empty screenshot from client')
    end }
    SetTimeout(10000, function()
        if not done then done = true captures[id] = nil cb(nil, 'client did not answer (screenshot-basic)') end
    end)
    TriggerClientEvent('heroshield:capture', src, id)
end

-- Take one screenshot of a player -> cb(dataUri or nil, error)
function HS.capture(src, cb)
    local res = HS.screenshotResource()
    if not Config.Screenshot.Enabled then return cb(nil, 'Config.Screenshot.Enabled = false') end
    if not res then return cb(nil, 'no screenshot resource started (screencapture / screenshot-basic)') end
    if not GetPlayerName(src) then return cb(nil, 'player left') end

    if res ~= 'screencapture' then return clientCapture(src, cb) end

    -- screencapture first, screenshot-basic if it does not answer in 6s
    local done = false
    local function fallback(why)
        if done then return end
        done = true
        HS.log('screencapture:', why, '-> trying screenshot-basic')
        clientCapture(src, cb)
    end
    local ok, err = pcall(function()
        exports.screencapture:serverCapture(src, { encoding = 'jpg', quality = Config.Screenshot.Quality }, function(data)
            if done then return end
            local img = normalize(data)
            if not img then return fallback('empty image') end
            done = true
            cb(img)
        end, 'base64')
    end)
    if not ok then return fallback(tostring(err)) end
    SetTimeout(3000, function() fallback('no answer') end)
end

-- Save an image -> cb(url or nil). UploadUrl (imgbb...) first, else the dashboard.
function HS.storeImage(data, meta, cb)
    cb = cb or function() end
    if not data then return cb(nil) end

    local upload = Config.Screenshot.UploadUrl or ''
    if upload ~= '' then
        local b64 = data:gsub('^data:image/%w+;base64,', '')
        PerformHttpRequest(upload, function(code, body)
            local ok, res = pcall(json.decode, body or '')
            local link
            if ok and type(res) == 'table' then
                link = (type(res.data) == 'table' and (res.data.url or res.data.display_url)) or res.url or res.link
                if not link and type(res.attachments) == 'table' and res.attachments[1] then link = res.attachments[1].url end
            end
            if not link and type(body) == 'string' then link = body:match('(https?://[^"%s]+%.[JjPpWw][PpNnEe][GgEe]?[Gg]?)') end
            if not link then HS.print('Error', ('Image upload failed (HTTP %s). Check Config.Screenshot.UploadUrl'):format(tostring(code))) end
            cb(link)
        end, 'POST', (Config.Screenshot.UploadField or 'image') .. '=' .. urlencode(b64),
            { ['Content-Type'] = 'application/x-www-form-urlencoded' })
    elseif HS.dashboardOn() then
        meta.image = data
        HS.api('/upload', meta, function(code, res)
            if not (res and res.url) then
                HS.print('Error', ('Proof upload to dashboard failed (HTTP %s): %s'):format(tostring(code),
                    tostring(res and res.error or 'no answer')))
            end
            cb(res and res.url or nil)
        end)
    else
        HS.print('Error', 'Proof not saved: set Config.DashboardURL + LicenseKey, or Config.Screenshot.UploadUrl')
        cb(nil)
    end
end

-- ===== Discord embeds =====
function HS.playerCard(src)
    local card = { src = src, name = GetPlayerName(src) or '?', license = HS.license(src) }
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then card.discord = id:sub(9) end
        if id:sub(1, 6) == 'steam:' then card.steam = id end
    end
    return card
end

local STYLE = {
    ban  = { title = '🔨 Player Banned',  color = 15548997, action = 'BAN' },
    kick = { title = '👢 Player Kicked',  color = 16753920, action = 'KICK' },
    log  = { title = '⚠️ Suspicious Activity', color = 16705372, action = 'LOG' },
}

function HS.embedBase(title, color)
    local site = HS.siteUrl()
    local logo = site ~= '' and (site .. '/assets/logo.png') or nil
    return {
        author = { name = 'HeRo Shield • Anti-Cheat', icon_url = logo, url = site ~= '' and site or nil },
        title = title, color = color,
        thumbnail = logo and { url = logo } or nil,
        footer = { text = ('HeRo Shield v%s'):format(HS.VERSION), icon_url = logo },
        timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    }
end

function HS.sendEmbed(embed, webhook)
    webhook = webhook or Config.Webhook
    if not webhook or webhook == '' then return end
    PerformHttpRequest(webhook, function() end, 'POST', json.encode({ username = 'HeRo Shield', embeds = { embed } }),
        { ['Content-Type'] = 'application/json' })
end

local function webhookUrl(base, extra)
    return base .. (base:find('?', 1, true) and '&' or '?') .. extra
end

local function buildPunishEmbed(kind, t, image)
    local style = STYLE[kind] or STYLE.log
    local e = HS.embedBase(style.title, style.color)
    e.description = kind == 'ban' and ('**%s** was permanently banned from the server.'):format(t.name)
        or kind == 'kick' and ('**%s** was kicked from the server.'):format(t.name)
        or ('**%s** triggered a detection.'):format(t.name)
    e.fields = {
        { name = '👤 Player', value = ('%s\n`ID %d`'):format(t.name, t.src), inline = true },
        { name = '💬 Discord', value = t.discord and ('<@%s>'):format(t.discord) or '`Not linked`', inline = true },
        { name = '⚖️ Action', value = ('`%s`'):format(style.action), inline = true },
        { name = '📌 Reason', value = ('```diff\n- %s\n```'):format(tostring(t.reason):upper()) },
        { name = '📝 Detail', value = ('```%s```'):format(t.detail ~= '' and t.detail or '-') },
        { name = '🔑 License', value = ('`%s`'):format(t.license) },
    }
    if kind == 'ban' then
        e.fields[#e.fields + 1] = { name = '⏱️ Duration', value = '`Permanent`', inline = true }
        e.fields[#e.fields + 1] = { name = '🆔 Ban ID', value = ('`%s`'):format(t.id), inline = true }
        e.fields[#e.fields + 1] = { name = '📸 Proof', value = image and 'Screenshot below • replay on the dashboard' or '`Loading...`', inline = true }
    end
    if image then e.image = { url = image } end
    return e
end

-- First call sends the embed right away. A later call with an image edits the same message.
function HS.punishEmbed(kind, t, image)
    local webhook = HS.webhook(kind == 'ban' and 'Ban' or kind == 'kick' and 'Kick' or 'Warn')
    if not webhook or webhook == '' then return end
    local body = json.encode({ username = 'HeRo Shield', embeds = { buildPunishEmbed(kind, t, image) } })
    local headers = { ['Content-Type'] = 'application/json' }

    if t.msgId then
        return PerformHttpRequest(webhook:gsub('%?.*$', '') .. '/messages/' .. t.msgId, function() end, 'PATCH', body, headers)
    end
    if image and t.sending then t.pendingImage = image return end

    t.sending = true
    PerformHttpRequest(webhookUrl(webhook, 'wait=true'), function(code, res)
        local ok, data = pcall(json.decode, res or '')
        if ok and type(data) == 'table' and data.id then t.msgId = data.id end
        if t.pendingImage and t.msgId then
            local img = t.pendingImage
            t.pendingImage = nil
            HS.punishEmbed(kind, t, img)
        end
    end, 'POST', body, headers)
end

-- ===== Ban proof =====
local function canStore()
    return (Config.Screenshot.UploadUrl or '') ~= '' or HS.dashboardOn()
end

function HS.collectProof(src, banId, onImage, onDone)
    if not Config.Screenshot.Enabled or not HS.screenshotResource() or not canStore() or not GetPlayerName(src) then
        HS.print('Error', ('No proof for %s: %s'):format(banId,
            not HS.screenshotResource() and 'no screenshot resource started'
            or not canStore() and 'no dashboard and no UploadUrl' or 'screenshots disabled'))
        onImage(nil)
        if Config.Webhook ~= '' and GetResourceState('screenshot-basic') == 'started' then
            TriggerClientEvent('heroshield:shot', src, Config.Webhook)
        end
        return SetTimeout(3000, onDone)
    end

    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then FreezeEntityPosition(ped, true) end

    -- The player is dropped as soon as screenshots + replay are RECEIVED (~2-4s).
    -- Uploads keep going in the background after the drop.
    local p = {
        src = src, shots = {}, replay = {}, uploads = 0,
        shotsDone = false, replayDone = not Config.Screenshot.Replay,
        embedSent = false, saved = false, dropped = false,
    }
    pending[banId] = p

    function p.sendEmbed()
        if p.embedSent then return end
        p.embedSent = true
        onImage(p.shots[1])
    end

    function p.drop()
        if p.dropped then return end
        p.dropped = true
        onDone()
    end

    function p.save(force)
        if p.saved then return end
        if not force and (not p.shotsDone or not p.replayDone or p.uploads > 0) then return end
        p.saved = true
        pending[banId] = nil
        p.sendEmbed()
        table.sort(p.replay, function(a, b) return a.i < b.i end)
        local replay = {}
        for _, r in ipairs(p.replay) do replay[#replay + 1] = r.url end
        HS.api('/proof', { banId = banId, shots = p.shots, replay = replay, interval = tonumber(Config.Screenshot.ReplayInterval) or 8 })
    end

    -- everything received -> drop now, save when uploads end
    function p.finish()
        if p.shotsDone and (p.replayDone or p.replayTimedOut) then p.drop() end
        p.save()
    end

    function p.store(data, meta, onUrl)
        p.uploads = p.uploads + 1
        HS.storeImage(data, meta, function(url)
            p.uploads = p.uploads - 1
            if url then onUrl(url) end
            p.finish()
        end)
    end

    if Config.Screenshot.Replay then TriggerClientEvent('heroshield:replay', src, banId) end

    local count = math.max(1, math.min(10, tonumber(Config.Screenshot.ProofShots) or 1))
    local gap = math.max(200, tonumber(Config.Screenshot.ProofGap) or 600)
    local function shot(i)
        if i > count or not GetPlayerName(src) then
            p.shotsDone = true
            return p.finish()
        end
        HS.capture(src, function(data, err)
            if not data then HS.print('Error', 'Proof screenshot failed: ' .. tostring(err)) end
            if data then
                p.store(data, { kind = 'ban', banId = banId, index = i - 1 }, function(url)
                    p.shots[#p.shots + 1] = url
                    p.sendEmbed()
                end)
            end
            SetTimeout(gap, function() shot(i + 1) end)
        end)
    end
    shot(1)

    -- frozen cheater is kicked as soon as proof is received:
    -- max MaxWait without replay, max ReplayMaxWait while the replay is being sent
    local maxWait = math.max(1000, tonumber(Config.Screenshot.MaxWait) or 3000)
    if Config.Screenshot.Replay then
        maxWait = math.max(maxWait, tonumber(Config.Screenshot.ReplayMaxWait) or 10000)
    end
    SetTimeout(maxWait, function()
        p.replayTimedOut = true
        p.drop()
    end)
    SetTimeout(20000, p.sendEmbed)                    -- embed even if uploads are slow
    SetTimeout(60000, function() p.save(true) end)    -- save whatever was uploaded
end

-- ===== Data from clients =====
RegisterNetEvent('heroshield:upload', function(token, kind, id, index, data)
    local src = source
    local pl = HS.players[src]
    if not pl or pl.token ~= token or type(id) ~= 'string' then return end

    if kind == 'capture' then
        local c = captures[id]
        if c and c.src == src then c.cb(type(data) == 'string' and #data < 4000000 and data or nil) end
        return
    end

    local p = pending[id]
    if not p or p.src ~= src then return end

    if kind == 'replaydone' then
        p.replayDone = true
        return p.finish()
    end
    if p.dropped then return end

    if kind == 'replay' and type(data) == 'string' and #data < 4000000 and data:sub(1, 11) == 'data:image/' then
        local i = tonumber(index) or 0
        p.store(data, { kind = 'replay', banId = id, index = i }, function(url)
            p.replay[#p.replay + 1] = { i = i, url = url }
        end)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    for _, p in pairs(pending) do
        if p.src == src then
            p.shotsDone, p.replayDone, p.dropped = true, true, true
            p.save()
        end
    end
    for id, c in pairs(captures) do
        if c.src == src then c.cb(nil) captures[id] = nil end
    end
end)

-- hsproof [id] : test screenshot + upload on a player, prints the result
RegisterCommand('hsproof', function(src, args)
    if src ~= 0 and not HS.isAdmin(src) then return end
    local target = tonumber(args[1])
    if not target or not GetPlayerName(target) then return print('Usage: hsproof [player id]') end
    HS.print('System', ('Proof test on %s... (resource: %s)'):format(GetPlayerName(target), tostring(HS.screenshotResource())))
    HS.capture(target, function(data, err)
        if not data then return HS.print('Error', 'Screenshot failed: ' .. tostring(err)) end
        HS.print('System', ('Screenshot OK (%d KB). Uploading...'):format(math.floor(#data / 1365)))
        HS.storeImage(data, { kind = 'live', identifier = HS.license(target) }, function(url)
            if url then HS.print('System', '^2Proof works!^7 ' .. url)
            else HS.print('Error', 'Upload failed (see error above).') end
        end)
    end)
end, true)
