-- Screenshots, ban proof (shots + replay), image upload and Discord embeds
local pending = {}    -- [banId] = proof in progress
local captures = {}   -- [id] = screenshot asked to a client
local nextId = 0

local function normalize(d)
    if type(d) ~= 'string' or #d < 100 then return nil end
    if d:sub(1, 5) ~= 'data:' then d = 'data:image/jpeg;base64,' .. d end
    return d
end

local function urlencode(s)
    return (s:gsub('[^%w%-_%.~]', function(c) return ('%%%02X'):format(c:byte()) end))
end

function HS.screenshotResource()
    local r = Config.Screenshot.Resource
    if r == 'auto' then
        if GetResourceState('screencapture') == 'started' then return 'screencapture' end
        if GetResourceState('screenshot-basic') == 'started' then return 'screenshot-basic' end
        return nil
    end
    return GetResourceState(r) == 'started' and r or nil
end

function HS.siteUrl()
    local base = HS.baseUrl and HS.baseUrl() or ''
    return (base:gsub('/api$', ''))
end

-- Take one screenshot of a player -> cb(dataUri or nil)
function HS.capture(src, cb)
    local res = HS.screenshotResource()
    if not Config.Screenshot.Enabled or not res or not GetPlayerName(src) then return cb(nil) end

    local done = false
    local function finish(d)
        if done then return end
        done = true
        cb(normalize(d))
    end
    SetTimeout(12000, function() finish(nil) end)

    if res == 'screencapture' then
        local ok = pcall(function()
            exports.screencapture:serverCapture(src, { encoding = 'jpg', quality = Config.Screenshot.Quality },
                function(data) finish(data) end, 'base64')
        end)
        if ok then return end
        HS.log('screencapture failed, trying screenshot-basic')
        if GetResourceState('screenshot-basic') ~= 'started' then return finish(nil) end
    end

    nextId = nextId + 1
    local id = tostring(nextId)
    captures[id] = { src = src, cb = function(d) captures[id] = nil finish(d) end }
    TriggerClientEvent('heroshield:capture', src, id)
end

-- Save an image -> cb(url or nil). UploadUrl (imgbb...) first, else the dashboard.
function HS.storeImage(data, meta, cb)
    cb = cb or function() end
    if not data then return cb(nil) end

    local upload = Config.Screenshot.UploadUrl or ''
    if upload ~= '' then
        local b64 = data:gsub('^data:image/%w+;base64,', '')
        PerformHttpRequest(upload, function(code, body)
            local ok, res = pcall(json.decode, body or '')
            local link
            if ok and type(res) == 'table' then
                link = (type(res.data) == 'table' and (res.data.url or res.data.display_url)) or res.url or res.link
                if not link and type(res.attachments) == 'table' and res.attachments[1] then link = res.attachments[1].url end
            end
            if not link and type(body) == 'string' then link = body:match('(https?://[^"%s]+%.[JjPpWw][PpNnEe][GgEe]?[Gg]?)') end
            if not link then HS.print('Error', ('Image upload failed (HTTP %s). Check Config.Screenshot.UploadUrl'):format(tostring(code))) end
            cb(link)
        end, 'POST', (Config.Screenshot.UploadField or 'image') .. '=' .. urlencode(b64),
            { ['Content-Type'] = 'application/x-www-form-urlencoded' })
    elseif HS.dashboardOn() then
        meta.image = data
        HS.api('/upload', meta, function(_, res) cb(res and res.url or nil) end)
    else
        cb(nil)
    end
end

-- ===== Discord embeds =====
function HS.playerCard(src)
    local card = { src = src, name = GetPlayerName(src) or '?', license = HS.license(src) }
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then card.discord = id:sub(9) end
        if id:sub(1, 6) == 'steam:' then card.steam = id end
    end
    return card
end

local STYLE = {
    ban  = { title = '🔨 Player Banned',  color = 15548997, action = 'BAN' },
    kick = { title = '👢 Player Kicked',  color = 16753920, action = 'KICK' },
    log  = { title = '⚠️ Suspicious Activity', color = 16705372, action = 'LOG' },
}

function HS.embedBase(title, color)
    local site = HS.siteUrl()
    local logo = site ~= '' and (site .. '/assets/logo.png') or nil
    return {
        author = { name = 'HeRo Shield • Anti-Cheat', icon_url = logo, url = site ~= '' and site or nil },
        title = title, color = color,
        thumbnail = logo and { url = logo } or nil,
        footer = { text = ('HeRo Shield v%s'):format(HS.VERSION), icon_url = logo },
        timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    }
end

function HS.sendEmbed(embed, webhook)
    webhook = webhook or Config.Webhook
    if not webhook or webhook == '' then return end
    PerformHttpRequest(webhook, function() end, 'POST', json.encode({ username = 'HeRo Shield', embeds = { embed } }),
        { ['Content-Type'] = 'application/json' })
end

function HS.punishEmbed(kind, t, image)
    local style = STYLE[kind] or STYLE.log
    local e = HS.embedBase(style.title, style.color)
    e.description = kind == 'ban' and ('**%s** was permanently banned from the server.'):format(t.name)
        or kind == 'kick' and ('**%s** was kicked from the server.'):format(t.name)
        or ('**%s** triggered a detection.'):format(t.name)
    e.fields = {
        { name = '👤 Player', value = ('%s\n`ID %d`'):format(t.name, t.src), inline = true },
        { name = '💬 Discord', value = t.discord and ('<@%s>'):format(t.discord) or '`Not linked`', inline = true },
        { name = '⚖️ Action', value = ('`%s`'):format(style.action), inline = true },
        { name = '📌 Reason', value = ('```diff\n- %s\n```'):format(tostring(t.reason):upper()) },
        { name = '📝 Detail', value = ('```%s```'):format(t.detail ~= '' and t.detail or '-') },
        { name = '🔑 License', value = ('`%s`'):format(t.license) },
    }
    if kind == 'ban' then
        e.fields[#e.fields + 1] = { name = '⏱️ Duration', value = '`Permanent`', inline = true }
        e.fields[#e.fields + 1] = { name = '🆔 Ban ID', value = ('`%s`'):format(t.id), inline = true }
        e.fields[#e.fields + 1] = { name = '📸 Proof', value = image and 'Screenshot below • replay on the dashboard' or '`No screenshot`', inline = true }
    end
    if image then e.image = { url = image } end
    HS.sendEmbed(e, Config.Webhook)
end

-- ===== Ban proof =====
local function canStore()
    return (Config.Screenshot.UploadUrl or '') ~= '' or HS.dashboardOn()
end

function HS.collectProof(src, banId, onImage, onDone)
    if not Config.Screenshot.Enabled or not HS.screenshotResource() or not canStore() or not GetPlayerName(src) then
        onImage(nil)
        if Config.Webhook ~= '' and GetResourceState('screenshot-basic') == 'started' then
            TriggerClientEvent('heroshield:shot', src, Config.Webhook)
        end
        return SetTimeout(3000, onDone)
    end

    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then FreezeEntityPosition(ped, true) end

    local p = {
        src = src, shots = {}, replay = {}, uploads = 0,
        shotsDone = false, replayDone = not Config.Screenshot.Replay,
        embedSent = false, finished = false,
    }
    pending[banId] = p

    function p.sendEmbed()
        if p.embedSent then return end
        p.embedSent = true
        onImage(p.shots[1])
    end

    function p.finish(force)
        if p.finished then return end
        if not force and (not p.shotsDone or not p.replayDone or p.uploads > 0) then return end
        p.finished = true
        pending[banId] = nil
        p.sendEmbed()
        table.sort(p.replay, function(a, b) return a.i < b.i end)
        local replay = {}
        for _, r in ipairs(p.replay) do replay[#replay + 1] = r.url end
        HS.api('/proof', { banId = banId, shots = p.shots, replay = replay })
        onDone()
    end

    function p.store(data, meta, onUrl)
        p.uploads = p.uploads + 1
        HS.storeImage(data, meta, function(url)
            p.uploads = p.uploads - 1
            if url then onUrl(url) end
            p.finish()
        end)
    end

    if Config.Screenshot.Replay then TriggerClientEvent('heroshield:replay', src, banId) end

    local count = math.max(1, math.min(10, tonumber(Config.Screenshot.ProofShots) or 1))
    local gap = math.max(200, tonumber(Config.Screenshot.ProofGap) or 600)
    local function shot(i)
        if i > count or not GetPlayerName(src) then
            p.shotsDone = true
            return p.finish()
        end
        HS.capture(src, function(data)
            if data then
                p.store(data, { kind = 'ban', banId = banId, index = i - 1 }, function(url)
                    p.shots[#p.shots + 1] = url
                    p.sendEmbed()
                end)
            end
            SetTimeout(gap, function() shot(i + 1) end)
        end)
    end
    shot(1)

    SetTimeout(15000, p.sendEmbed)                    -- embed even if slow
    SetTimeout(35000, function() p.finish(true) end)  -- drop even if slow
end

-- ===== Data from clients =====
RegisterNetEvent('heroshield:upload', function(token, kind, id, index, data)
    local src = source
    local pl = HS.players[src]
    if not pl or pl.token ~= token or type(id) ~= 'string' then return end

    if kind == 'capture' then
        local c = captures[id]
        if c and c.src == src then c.cb(type(data) == 'string' and #data < 4000000 and data or nil) end
        return
    end

    local p = pending[id]
    if not p or p.src ~= src then return end

    if kind == 'replaydone' then
        p.replayDone = true
        return p.finish()
    end

    if kind == 'replay' and type(data) == 'string' and #data < 4000000 and data:sub(1, 11) == 'data:image/' then
        local i = tonumber(index) or 0
        p.store(data, { kind = 'replay', banId = id, index = i }, function(url)
            p.replay[#p.replay + 1] = { i = i, url = url }
        end)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    for _, p in pairs(pending) do
        if p.src == src then
            p.shotsDone, p.replayDone = true, true
            p.finish()
        end
    end
    for id, c in pairs(captures) do
        if c.src == src then c.cb(nil) captures[id] = nil end
    end
end)
