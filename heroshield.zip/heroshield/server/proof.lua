-- Ban proof (screenshot + replay), Discord embeds, live view uploads
local pending = {}

function HS.playerCard(src)
    local card = { src = src, name = GetPlayerName(src) or '?', license = HS.license(src), discord = nil }
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then card.discord = id:sub(9) end
    end
    return card
end

local STYLE = {
    ban  = { title = '🛡️ User Banned', color = 15548997 },
    kick = { title = '👢 User Kicked', color = 16753920 },
    log  = { title = '⚠️ Detection',   color = 16705372 },
}

-- Embed like: User / Reason / Detail / Duration / Proof
function HS.punishEmbed(kind, t, image)
    local webhook = Config.Webhook
    if not webhook or webhook == '' then return end
    local style = STYLE[kind] or STYLE.log
    local user = (t.discord and ('<@%s> '):format(t.discord) or '') .. ('**%s**\n`%s`'):format(t.name, t.license)

    local fields = {
        { name = 'User', value = user },
        { name = 'Reason', value = ('```%s```'):format(tostring(t.reason):upper()) },
        { name = 'Detail', value = ('```%s```'):format(t.detail ~= '' and t.detail or '-') },
    }
    if kind == 'ban' then fields[#fields + 1] = { name = 'Duration', value = 'Permanent' } end
    if kind ~= 'log' then fields[#fields + 1] = { name = 'Proof', value = image and 'Screenshot below. Replay on the dashboard.' or 'No screenshot' } end

    local footer = kind == 'ban' and ('Ban ID: %s'):format(t.id) or (kind == 'kick' and 'Punishment: KICK' or 'Action: LOG')
    PerformHttpRequest(webhook, function() end, 'POST', json.encode({
        username = 'HeRo Shield',
        embeds = {{
            title = style.title, color = style.color, fields = fields,
            image = image and { url = image } or nil,
            footer = { text = footer .. ' • HeRo Shield' },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        }},
    }), { ['Content-Type'] = 'application/json' })
end

local function canProof(src)
    return Config.Proof.Screenshot and HS.dashboardOn() and GetResourceState('screenshot-basic') == 'started'
        and GetPlayerName(src) ~= nil
end

-- Ask the client for proof, then call onImage(url or nil) and onDone()
function HS.collectProof(src, banId, onImage, onDone)
    if not canProof(src) then
        onImage(nil)
        if Config.Webhook ~= '' and GetResourceState('screenshot-basic') == 'started' then
            TriggerClientEvent('heroshield:shot', src, Config.Webhook)
        end
        return SetTimeout(3000, onDone)
    end

    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then FreezeEntityPosition(ped, true) end

    local p = { src = src, image = nil, embedSent = false, finished = false }
    function p.sendEmbed()
        if p.embedSent then return end
        p.embedSent = true
        onImage(p.image)
    end
    function p.finish()
        if p.finished then return end
        p.finished = true
        pending[banId] = nil
        p.sendEmbed()
        onDone()
    end
    pending[banId] = p

    TriggerClientEvent('heroshield:proof', src, banId)
    SetTimeout(10000, p.sendEmbed)   -- embed even if the screenshot is slow
    SetTimeout(25000, p.finish)      -- drop even if uploads are slow
end

local function upload(data, cb)
    HS.api('/upload', data, cb)
end

RegisterNetEvent('heroshield:upload', function(token, kind, banId, index, data)
    local src = source
    local pl = HS.players[src]
    if not pl or pl.token ~= token then return end

    if kind == 'done' then
        local p = pending[banId]
        if p and p.src == src then SetTimeout(1500, p.finish) end
        return
    end

    if type(data) ~= 'string' or #data > 3000000 or data:sub(1, 11) ~= 'data:image/' then return end

    if kind == 'live' then
        return upload({ kind = 'live', identifier = HS.license(src), image = data })
    end

    local p = pending[banId]
    if not p or p.src ~= src then return end

    if kind == 'ban' then
        upload({ kind = 'ban', banId = banId, image = data }, function(_, res)
            if res and res.url then p.image = res.url end
            p.sendEmbed()
        end)
    elseif kind == 'replay' then
        upload({ kind = 'replay', banId = banId, index = tonumber(index) or 0, image = data })
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    for _, p in pairs(pending) do
        if p.src == src then p.finish() end
    end
end)
