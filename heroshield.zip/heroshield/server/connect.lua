-- Connection checks (Settings > Connection)
local vpnCache = {}

local function hasId(src, prefix)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, #prefix) == prefix then return id end
    end
end

local function badName(name)
    name = tostring(name or '')
    if #name < 3 or #name > 32 then return 'Your name must be 3-32 characters.' end
    if name:find('[<>{}\\%^~`]') then return 'Your name has forbidden characters.' end
    if name:find('[\128-\255]') then return 'Your name has emojis or special characters.' end
    if name:lower():find('https?://') or name:lower():find('discord%.gg') then return 'Links are not allowed in your name.' end
end

local function refuse(src, name, reason)
    local wh = HS.webhook('Vpn')
    if wh and wh ~= '' then
        local e = HS.embedBase('🚫 Connection refused', 15548997)
        e.description = ('**Player:** %s\n**Reason:** %s\n`%s`'):format(name or '?', reason, hasId(src, 'license:') or '?')
        HS.sendEmbed(e, wh)
    end
    HS.print('System', ('Connection refused for %s: %s'):format(name or '?', reason))
    return reason
end

-- returns a reason string to refuse, or nil
function HS.connectCheck(src, name)
    local s = Config.Settings
    -- XSS / html in name (exploits NUI scoreboards, chat, admin menus)
    local d = Config.Detections.XssExploit
    if d and d.enabled and tostring(name or ''):find('[<>]') then
        return refuse(src, name, 'Your name contains forbidden characters (< >).')
    end
    -- spoofed identifiers: no Rockstar license or no hardware tokens
    if s.AntiSpoof then
        if not hasId(src, 'license:') then return refuse(src, name, 'Invalid Rockstar license.') end
        if (GetNumPlayerTokens(src) or 0) == 0 then return refuse(src, name, 'Spoofed client (no hardware id).') end
        local count = 0
        for _, id in ipairs(GetPlayerIdentifiers(src)) do if id:sub(1, 8) == 'license:' then count = count + 1 end end
        if count > 1 then return refuse(src, name, 'Spoofed identifiers.') end
    end
    if s.RequireSteam and GetConvar('steam_webApiKey', '') == '' then
        HS.print('Error', 'Require Steam is ON but steam_webApiKey is not set in server.cfg: Steam check skipped.')
    elseif s.RequireSteam and not hasId(src, 'steam:') then
        return refuse(src, name, 'Steam must be open to join this server.')
    end
    if s.RequireDiscord and not hasId(src, 'discord:') then
        return refuse(src, name, 'Discord must be open to join this server.')
    end
    if s.RequireNormalName then
        local why = badName(name)
        if why then return refuse(src, name, why) end
    end
    if s.AntiVpn then
        local ip = (hasId(src, 'ip:') or ''):sub(4)
        if ip ~= '' and ip ~= '127.0.0.1' then
            local cached = vpnCache[ip]
            if cached == nil then
                local p = promise.new()
                PerformHttpRequest(('http://ip-api.com/json/%s?fields=status,proxy,hosting'):format(ip), function(code, body)
                    local ok, res = pcall(json.decode, body or '')
                    p:resolve(ok and type(res) == 'table' and res.status == 'success' and (res.proxy or res.hosting) or false)
                end, 'GET')
                SetTimeout(5000, function() p:resolve(false) end)
                cached = Citizen.Await(p)
                vpnCache[ip] = cached
            end
            if cached then return refuse(src, name, 'VPN / proxy connections are not allowed.') end
        end
    end
end
