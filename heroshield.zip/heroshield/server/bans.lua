local FILE = 'data/bans.json'

do
    local ok, data = pcall(json.decode, LoadResourceFile(HS.RES, FILE) or '[]')
    HS.bans = (ok and type(data) == 'table') and data or {}
end

function HS.saveBans()
    SaveResourceFile(HS.RES, FILE, json.encode(HS.bans, { indent = true }), -1)
end

function HS.findBan(idList)
    local set = {}
    for _, id in ipairs(idList) do set[id] = true end
    for _, b in ipairs(HS.bans) do
        for _, id in ipairs(b.identifiers or {}) do
            if set[id] then return b end
        end
    end
end

function HS.addBan(src, name, reason, info)
    local banId = HS.genId()
    HS.bans[#HS.bans + 1] = {
        id = banId, name = name, reason = reason, info = tostring(info or ''),
        identifiers = HS.ids(src), date = os.date('%Y-%m-%d %H:%M:%S'),
    }
    HS.saveBans()
    return banId
end

function HS.removeBan(banId)
    banId = tostring(banId or ''):upper()
    for i, b in ipairs(HS.bans) do
        if b.id == banId then
            table.remove(HS.bans, i)
            HS.saveBans()
            return b
        end
    end
end

-- Sync with dashboard every minute (unbans + settings)
CreateThread(function()
    Wait(15000)
    while true do
        HS.api('/sync', nil, function(code, res)
            if code ~= 200 or type(res) ~= 'table' then return end
            HS.applySettings(res.settings)
            for _, banId in ipairs(res.unbans or {}) do
                local b = HS.removeBan(banId)
                if b then
                    HS.print('Dashboard', ('Unbanned %s (%s)'):format(b.id, b.name))
                    HS.event('Admin', 'Unban (dashboard)', ('%s (%s)'):format(b.id, b.name))
                end
            end
        end)
        Wait(60000)
    end
end)
