-- Startup message in the console
local BANNER = {
    [[  ________         __  __     ____           _____ __    _      __    __]],
    [[ |  ____  |       / / / /__  / __ \____     / ___// /_  (_)__  / /___/ /]],
    [[ | | HS | |      / /_/ / _ \/ /_/ / __ \    \__ \/ __ \/ / _ \/ / __  / ]],
    [[  \ \__/ /      / __  /  __/ _, _/ /_/ /   ___/ / / / / /  __/ / /_/ /  ]],
    [[   \____/      /_/ /_/\___/_/ |_|\____/   /____/_/ /_/_/\___/_/\__,_/   ]],
}

local function finish()
    print(' ')
    for _, line in ipairs(BANNER) do print('^5' .. line .. '^7') end
    print(' ')
    HS.print('Version', ('Welcome to HeRo Shield, version %s.'):format(HS.VERSION))
    HS.print('Framework', ('Framework detected: %s'):format(HS.framework))
    HS.print('System', ('%d bans loaded.'):format(#HS.bans))

    if Config.Webhook == '' then
        HS.print('Webhook', 'No webhook set. Add one in config.lua or in the dashboard.')
    end

    local shot = HS.screenshotResource()
    if Config.Screenshot.Enabled then
        if shot then
            HS.print('System', ('Screenshots: %s'):format(shot))
        else
            HS.print('Error', 'No screenshot resource started (screencapture or screenshot-basic). Proof and live view are off.')
        end
    end

    -- Server settings that block most menu abuse (objects, taking control of entities)
    if GetConvar('sv_entityLockdown', 'inactive') == 'inactive' then
        HS.print('System', '^3Tip:^7 add "set sv_entityLockdown relaxed" to server.cfg (blocks entities spawned by menus).')
    end
    if GetConvarInt('sv_filterRequestControl', 0) == 0 then
        HS.print('System', '^3Tip:^7 add "set sv_filterRequestControl 4" to server.cfg (stops menus taking other players cars/objects).')
    end

    HS.print('System', 'HeRo Shield loaded. Your server is protected!')
    HS.event('Startup', 'Anti-cheat started',
        ('HeRo Shield v%s is running.\nFramework: %s\nBans: %d'):format(HS.VERSION, HS.framework, #HS.bans))
end

CreateThread(function()
    Wait(1500)

    if not HS.dashboardOn() then
        HS.print('Auth', 'No license key set. Dashboard is off.')
        return finish()
    end

    HS.print('Auth', 'Connecting to ' .. HS.baseUrl() .. ' ...')
    local done = false

    HS.api('/sync', nil, function(code, res)
        if done then return end
        done = true
        if code == 200 then
            HS.print('Auth', ('^2Connected to the dashboard%s.'):format(res and res.server and (' as ' .. res.server) or ''))
            if res then HS.applySettings(res.settings) end
        elseif code == 401 then
            HS.print('Error', 'Invalid license key. Check it in the dashboard.')
        else
            HS.print('Error', ('Dashboard unreachable (HTTP %s) at %s'):format(tostring(code), HS.baseUrl() .. '/sync'))
            if code == 404 then
                HS.print('Error', 'Check Config.DashboardURL in shared/config.lua (your Render link, e.g. https://hero-shield.onrender.com).')
            end
        end
        finish()
    end)

    -- Do not wait forever (free hosts can take ~30s to wake up)
    SetTimeout(40000, function()
        if done then return end
        done = true
        HS.print('Error', 'Dashboard did not answer. Starting without it.')
        finish()
    end)
end)
