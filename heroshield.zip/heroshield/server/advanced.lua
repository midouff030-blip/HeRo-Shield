-- Advanced server checks: resource stop, frozen checks (heartbeat ticks), silent aim reports,
-- burn other players, vehicles (hijack, throw, plate change)
local function enabled(name) return Config.Detections[name] and Config.Detections[name].enabled end

-- ===== heartbeat with check counter: the checks must keep running =====
RegisterNetEvent('heroshield:hb', function(_, ticks)
    local src = source
    local p = HS.players[src]
    if not p then return end
    ticks = tonumber(ticks)
    if not ticks then return end
    local now = os.time()
    if p.lastTicks and p.lastTicksAt and enabled('Heartbeat') then
        local elapsed = now - p.lastTicksAt
        -- checks run every second: at least 25% must have run (lag safe)
        if elapsed >= 15 and (ticks - p.lastTicks) < elapsed * 0.25 then
            p.frozenChecks = (p.frozenChecks or 0) + 1
            if p.frozenChecks >= 2 then HS.detect(src, 'Heartbeat', ('anti-cheat checks stopped (%d/%ds)'):format(ticks - p.lastTicks, elapsed)) end
        else
            p.frozenChecks = 0
        end
    end
    p.lastTicks, p.lastTicksAt = ticks, now
end)

-- ===== resource stopped on the client but running on the server =====
RegisterNetEvent('heroshield:resstop', function(token, res)
    local src = source
    if type(res) ~= 'string' or not HS.valid(src, token) or not enabled('ResourceStop') then return end
    SetTimeout(3000, function()
        if GetResourceState(res) == 'started' and GetPlayerName(src) then
            HS.detect(src, 'ResourceStop', 'stopped resource: ' .. res)
        end
    end)
end)

-- ===== silent aim reports (from the victims) =====
local reports = {}   -- [attacker] = { [victim] = time }
RegisterNetEvent('heroshield:report', function(token, kind, attacker, dist)
    local src = source
    attacker = tonumber(attacker)
    if kind ~= 'silentaim' or not attacker or attacker == src or not HS.valid(src, token) then return end
    if not HS.players[attacker] or not enabled('SilentAim') then return end
    local now = os.time()
    reports[attacker] = reports[attacker] or {}
    reports[attacker][src] = now
    local victims = 0
    for v, t in pairs(reports[attacker]) do
        if now - t <= 60 then victims = victims + 1 else reports[attacker][v] = nil end
    end
    -- needs several different victims (one fake report cannot ban someone)
    if victims >= math.max(2, HS.value('SilentAim')) then
        reports[attacker] = nil
        HS.detect(attacker, 'SilentAim', ('%d players hit without line of sight (last %sm)'):format(victims, tostring(dist)))
    end
end)

-- ===== burning another player =====
AddEventHandler('fireEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('AntiBurn') or type(ev) ~= 'table' or type(ev.fires) ~= 'table' then return end
    for _, f in ipairs(ev.fires) do
        if f.isEntity and f.entityGlobalId then
            local ent = NetworkGetEntityFromNetworkId(f.entityGlobalId)
            if ent and ent ~= 0 and DoesEntityExist(ent) and GetEntityType(ent) == 1 and IsPedAPlayer(ent) then
                local owner = NetworkGetEntityOwner(ent)
                if owner and owner ~= src then
                    CancelEvent()
                    return HS.detect(src, 'AntiBurn', ('set player %d on fire'):format(owner))
                end
            end
        end
    end
end)

-- ===== vehicles: hijack, throw, plate change (every second) =====
local drivers, plates = {}, {}
local function playerFromPed(ped)
    if not ped or ped == 0 or not IsPedAPlayer(ped) then return nil end
    return NetworkGetEntityOwner(ped)
end

CreateThread(function()
    while true do
        Wait(1000)
        if next(HS.players) and (enabled('Hijack') or enabled('ThrowVehicle') or enabled('ChangePlate')) then
            local now = GetGameTimer()
            local seen = {}
            for _, veh in ipairs(GetAllVehicles()) do
                seen[veh] = true
                local driverPed = GetPedInVehicleSeat(veh, -1)
                local driver = playerFromPed(driverPed)

                -- hijack: driver changed from one player to another in under 1s
                local last = drivers[veh]
                if enabled('Hijack') and driver and last and last.src ~= driver and HS.players[driver]
                    and now - last.t <= 1500 and GetPlayerName(last.src) then
                    local oldPed = GetPlayerPed(last.src)
                    if oldPed ~= 0 and GetVehiclePedIsIn(oldPed, false) == 0 then
                        HS.detect(driver, 'Hijack', ('took the car of player %d instantly'):format(last.src))
                    end
                end
                drivers[veh] = driver and { src = driver, t = now } or (last and now - last.t < 3000 and last or nil)

                -- throw vehicle: empty car flying very fast, moved by a player who is not in it
                if enabled('ThrowVehicle') and driverPed == 0 then
                    local v = GetEntityVelocity(veh)
                    local speed = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
                    if speed > math.max(30, HS.value('ThrowVehicle')) then
                        local owner = NetworkGetEntityOwner(veh)
                        if owner and HS.players[owner] and GetVehiclePedIsIn(GetPlayerPed(owner), false) ~= veh then
                            local p = HS.players[owner]
                            p.throws = (p.throws or 0) + 1
                            if p.throws >= 2 then
                                p.throws = 0
                                HS.detect(owner, 'ThrowVehicle', ('empty vehicle at %.0f m/s'):format(speed))
                            end
                        end
                    end
                end

                -- plate change while driving
                if enabled('ChangePlate') and driver then
                    local plate = GetVehicleNumberPlateText(veh)
                    local old = plates[veh]
                    if old and old.src == driver and old.plate ~= plate then
                        HS.detect(driver, 'ChangePlate', ('plate %s -> %s'):format(old.plate, plate))
                    end
                    plates[veh] = { src = driver, plate = plate }
                elseif plates[veh] then
                    plates[veh] = nil
                end
            end
            for veh in pairs(drivers) do if not seen[veh] then drivers[veh] = nil end end
            for veh in pairs(plates) do if not seen[veh] then plates[veh] = nil end end
        end
    end
end)

AddEventHandler('playerDropped', function()
    reports[source] = nil
end)
