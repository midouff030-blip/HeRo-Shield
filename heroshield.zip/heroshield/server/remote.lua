-- Commands sent from the dashboard (live view, kick, ban)
local busy = false

local function findPlayer(identifier)
    for src in pairs(HS.players) do
        if GetPlayerName(src) and HS.license(src) == identifier then return src end
    end
end

CreateThread(function()
    Wait(20000)
    while true do
        Wait(4000)
        if HS.dashboardOn() and not busy and next(HS.players) then
            busy = true
            HS.api('/commands', nil, function(code, res)
                busy = false
                if code ~= 200 or type(res) ~= 'table' or type(res.commands) ~= 'table' then return end
                for _, cmd in ipairs(res.commands) do
                    local src = findPlayer(cmd.target)
                    if src then
                        if cmd.type == 'screenshot' then
                            local identifier = cmd.target
                            HS.capture(src, function(data)
                                if data then HS.api('/upload', { kind = 'live', identifier = identifier, image = data }) end
                            end)
                        elseif cmd.type == 'kick' or cmd.type == 'ban' then
                            local reason = tostring(cmd.reason or 'Dashboard'):sub(1, 60)
                            HS.event('Admin', 'Dashboard ' .. cmd.type, ('%s from the dashboard: %s'):format(cmd.type, reason), src)
                            HS.punish(src, reason, 'dashboard', cmd.type)
                        end
                    end
                end
            end)
            SetTimeout(15000, function() busy = false end)
        end
    end
end)
