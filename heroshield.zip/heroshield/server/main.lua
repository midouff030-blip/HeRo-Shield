function HS.punish(src, reason, info, action)
    src = tonumber(src)
    if not src or not GetPlayerName(src) then return end
    if HS.isAdmin(src) then
        HS.log('admin ignored:', GetPlayerName(src), reason)
        return
    end
    local p = HS.players[src]
    if p and p.punished then return end
    if p and action ~= 'log' then p.punished = true end

    local name = GetPlayerName(src)
    local idents = GetPlayerIdentifiers(src)
    local desc = ('**Player:** %s (ID %d)\n**Detection:** %s\n**Info:** %s\n**Action:** %s\n```%s```')
        :format(name, src, reason, tostring(info or '-'), action, table.concat(idents, '\n'))

    HS.log(name, reason, info, action)
    HS.api('/detection', { player = name, identifier = HS.license(src), reason = reason,
        info = tostring(info or ''), action = action, identifiers = idents })

    if action == 'log' then
        return HS.discord('Detection (log)', desc, 16753920)
    end

    if Config.Webhook ~= '' then TriggerClientEvent('heroshield:shot', src, Config.Webhook) end

    if action == 'ban' then
        local banId = HS.addBan(src, name, reason, info)
        HS.discord('Ban ' .. banId, desc, 16711680)
        HS.api('/ban', { banId = banId, player = name, identifier = HS.license(src),
            reason = reason, info = tostring(info or ''), identifiers = idents })
        SetTimeout(3000, function()
            if GetPlayerName(src) then DropPlayer(src, Config.BanMessage:format(reason, banId)) end
        end)
    else
        HS.discord('Kick', desc, 16776960)
        SetTimeout(3000, function()
            if GetPlayerName(src) then DropPlayer(src, Config.KickMessage:format(reason)) end
        end)
    end
end

function HS.detect(src, name, info)
    local d = Config.Detections[name]
    if d and d.enabled then HS.punish(src, name, info, d.action) end
end

exports('BanPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'ban') end)
exports('KickPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'kick') end)
exports('IsAdmin', function(src) return HS.isAdmin(src) end)

-- Ban check on connect
AddEventHandler('playerConnecting', function(_, _, deferrals)
    local src = source
    deferrals.defer()
    Wait(0)
    deferrals.update('HeRo Shield - checking...')
    local b = HS.findBan(HS.ids(src))
    if b then
        deferrals.done(Config.BanMessage:format(b.reason, b.id))
    else
        deferrals.done()
    end
end)

local function register(src)
    local token = HS.newToken()
    HS.players[src] = { token = token, lastHb = os.time(), joined = os.time(), expl = {}, ents = {} }
    TriggerClientEvent('heroshield:init', src, token, HS.isAdmin(src), Config.Detections)
    HS.api('/player', { event = 'join', player = GetPlayerName(src), identifier = HS.license(src) })
end

RegisterNetEvent('heroshield:ready', function()
    local src = source
    if not HS.players[src] then register(src) end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local p = HS.players[src]
    if p then
        HS.api('/player', { event = 'leave', player = GetPlayerName(src) or '?',
            identifier = HS.license(src), playtime = os.time() - p.joined })
    end
    HS.players[src] = nil
end)

-- Resource restart: register players already online
CreateThread(function()
    Wait(2000)
    for _, s in ipairs(GetPlayers()) do
        local src = tonumber(s)
        if src and not HS.players[src] then register(src) end
    end
end)

function HS.valid(src, token)
    local p = HS.players[src]
    if not p then return false end
    if p.token ~= token then
        HS.detect(src, 'Injection', 'invalid token')
        return false
    end
    return true
end

RegisterNetEvent('heroshield:hb', function(token)
    local src = source
    if HS.valid(src, token) then HS.players[src].lastHb = os.time() end
end)

RegisterNetEvent('heroshield:detect', function(token, name, info)
    local src = source
    if type(name) ~= 'string' or not Config.Detections[name] then return end
    if HS.valid(src, token) then HS.detect(src, name, info) end
end)

RegisterNetEvent('heroshield:resources', function(token, list)
    local src = source
    if type(list) ~= 'table' or not HS.valid(src, token) then return end
    for _, r in ipairs(list) do
        if type(r) == 'string' and GetResourceState(r) == 'missing' then
            return HS.detect(src, 'Injection', 'resource: ' .. r)
        end
    end
end)

-- Anti-cheat stopped on client = no heartbeat
CreateThread(function()
    while true do
        Wait(15000)
        if Config.Detections.Heartbeat.enabled then
            local now = os.time()
            for src, p in pairs(HS.players) do
                local late = now - p.lastHb
                if not p.punished and late > HS.value('Heartbeat') then
                    HS.detect(src, 'Heartbeat', ('no heartbeat for %ds'):format(late))
                end
            end
        end
    end
end)

print(('^5[HeRo Shield]^7 v%s started - %d bans loaded.'):format(HS.VERSION, #HS.bans))
