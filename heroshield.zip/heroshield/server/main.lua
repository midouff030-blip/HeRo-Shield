-- ===== Ban screen (was server/bancard.lua) =====
-- Ban screen (Adaptive Card) shown in the FiveM connect screen
-- Simple Adaptive Card (only basic elements = works on every FiveM client)
function HS.banCard(b)
    local cfg = Config.BanScreen
    local site = (HS.siteUrl and HS.siteUrl()) or ''
    local logo = (cfg.Logo ~= '' and cfg.Logo) or (site ~= '' and (site .. '/assets/logo.png')) or nil

    local body = {}
    if logo then
        body[#body + 1] = { type = 'Image', url = logo, size = 'Small', horizontalAlignment = 'Center' }
    end
    body[#body + 1] = { type = 'TextBlock', text = cfg.ServerName, size = 'ExtraLarge', weight = 'Bolder', horizontalAlignment = 'Center', wrap = true }
    body[#body + 1] = { type = 'TextBlock', text = 'HeRo Shield Anti-Cheat', size = 'Large', horizontalAlignment = 'Center', spacing = 'Medium' }
    body[#body + 1] = { type = 'TextBlock', text = 'You are permanently banned from this server', horizontalAlignment = 'Center', wrap = true, spacing = 'None' }
    body[#body + 1] = { type = 'TextBlock', text = ('Ban-ID: %s   |   Expires: Permanent'):format(b.id), color = 'Attention', weight = 'Bolder', size = 'Medium', horizontalAlignment = 'Center', spacing = 'Medium' }
    body[#body + 1] = { type = 'TextBlock', text = ('Reason: %s'):format(Config.Settings.RevealBanReason and tostring(b.reason or '?') or 'Cheating'), horizontalAlignment = 'Center', isSubtle = true, spacing = 'Small' }
    body[#body + 1] = { type = 'TextBlock', text = cfg.Message, color = 'Warning', weight = 'Bolder', horizontalAlignment = 'Center', wrap = true, spacing = 'Medium' }
    if cfg.ShowProof and type(b.proof) == 'string' and b.proof:sub(1, 8) == 'https://' then
        body[#body + 1] = { type = 'Image', url = b.proof, size = 'Stretch', spacing = 'Medium' }
    end

    local actions = {}
    local discord = (Config.Settings.DiscordInvite ~= '' and Config.Settings.DiscordInvite) or cfg.Discord
    if discord ~= '' then actions[#actions + 1] = { type = 'Action.OpenUrl', title = 'Discord', url = discord } end
    if cfg.Website ~= '' then actions[#actions + 1] = { type = 'Action.OpenUrl', title = 'Website', url = cfg.Website } end
    actions[#actions + 1] = { type = 'Action.Submit', title = 'Close', data = { close = true } }

    return json.encode({ type = 'AdaptiveCard', version = '1.2', body = body, actions = actions })
end

-- remember the first proof screenshot on the ban (shown on the ban screen)
function HS.setBanProof(banId, url)
    if not url then return end
    for _, b in ipairs(HS.bans) do
        if b.id == banId then
            b.proof = url
            HS.saveBans()
            return
        end
    end
end

-- Text shown when the player is kicked at the ban moment (FiveM only allows text here)
function HS.banDropText(reason, banId)
    local cfg = Config.BanScreen
    if not Config.Settings.RevealBanReason then reason = 'Cheating' end
    local lines = {
        ('🛡️ %s — HeRo Shield Anti-Cheat'):format(cfg.ServerName),
        '',
        'You have been permanently banned.',
        ('Ban-ID: %s   |   Expires: Permanent'):format(banId),
        ('Reason: %s'):format(tostring(reason)),
        '',
        cfg.Message,
    }
    local discord = (Config.Settings.DiscordInvite ~= '' and Config.Settings.DiscordInvite) or cfg.Discord
    if discord ~= '' then lines[#lines + 1] = 'Discord: ' .. discord end
    return table.concat(lines, '\n')
end

-- ===== Main =====
-- force = true skips the admin check (detections not in Config.AdminAllowed)
function HS.punish(src, reason, info, action, force)
    src = tonumber(src)
    if not src or not GetPlayerName(src) then return end
    if not force and HS.isAdmin(src) then
        HS.log('admin ignored:', GetPlayerName(src), reason)
        return
    end
    local p = HS.players[src]
    if p and p.punished then return end
    if p and action ~= 'log' then p.punished = true end

    local target = HS.playerCard(src)
    target.reason, target.detail = reason, tostring(info or '-')
    local idents = GetPlayerIdentifiers(src)

    HS.log(target.name, reason, info, action)
    HS.api('/detection', { player = target.name, identifier = target.license, reason = reason,
        info = target.detail, action = action, identifiers = idents })

    if action == 'log' then
        HS.print('Detection', ('%s (%d) - %s %s'):format(target.name, src, reason, target.detail))
        return HS.punishEmbed('log', target)
    end

    if action == 'ban' then
        local banId = HS.addBan(src, target.name, reason, info)
        target.id = banId
        HS.print('Ban', ('%s (%d) banned - %s [%s]'):format(target.name, src, reason, banId))
        HS.api('/ban', { banId = banId, player = target.name, identifier = target.license,
            reason = reason, info = target.detail, identifiers = idents })
        HS.punishEmbed('ban', target)   -- instant Discord message
        HS.collectProof(src, banId,
            function(image)
                if image then
                    HS.setBanProof(banId, image)
                    HS.punishEmbed('ban', target, image)
                end
            end,
            function()
                if GetPlayerName(src) then DropPlayer(src, HS.banDropText(reason, banId)) end
            end)
    else
        HS.print('Kick', ('%s (%d) kicked - %s'):format(target.name, src, reason))
        HS.punishEmbed('kick', target)
        SetTimeout(2000, function()
            if GetPlayerName(src) then DropPlayer(src, Config.KickMessage:format(reason)) end
        end)
    end
end

function HS.detect(src, name, info)
    local d = Config.Detections[name]
    if not d or not d.enabled then return end
    if HS.isAdmin(src) then
        -- txAdmin-only tools are filtered on the client: if it reached here, it was not txAdmin
        if Config.AdminAllowed[name] and not (Config.Settings.TxAdminIntegration and Config.AdminTxAdminOnly[name]) then return end
        return HS.punish(src, name, info, d.action, true)
    end
    HS.punish(src, name, info, d.action)
end

exports('BanPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'ban') end)
exports('KickPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'kick') end)
exports('IsAdmin', function(src) return HS.isAdmin(src) end)

-- Ban check on connect
AddEventHandler('playerConnecting', function(name, _, deferrals)
    local src = source
    deferrals.defer()
    Wait(0)
    deferrals.update('HeRo Shield - checking...')
    local b = HS.findBan(HS.ids(src))
    if b then
        local text = Config.BanMessage:format(Config.Settings.RevealBanReason and b.reason or 'Cheating', b.id)
        local closed = false
        local function close()
            if closed then return end
            closed = true
            deferrals.done(text)
        end
        local ok, err = false, 'Config.BanScreen.Enabled = false'
        if Config.BanScreen and Config.BanScreen.Enabled ~= false then
            ok, err = pcall(function()
                local card = HS.banCard(b)
                Wait(100)
                deferrals.presentCard(card, function() close() end)
            end)
        end
        if ok then
            HS.print('Ban', ('%s tried to join (banned %s) - ban screen shown'):format(name or '?', b.id))
            SetTimeout(45000, close)   -- never stay stuck
        else
            HS.print('Error', 'Ban screen failed: ' .. tostring(err))
            close()
        end
    else
        -- never block a player because of an error here
        local ok, refuse = pcall(function() return HS.connectCheck and HS.connectCheck(src, name) end)
        if not ok then HS.print('Error', 'Connection check failed: ' .. tostring(refuse)) refuse = nil end
        if refuse then deferrals.done('HeRo Shield: ' .. refuse) else deferrals.done() end
    end
end)

local function register(src, grace)
    local token = HS.newToken()
    HS.players[src] = { token = token, lastHb = os.time(), joined = os.time(), expl = {}, ents = {} }
    TriggerClientEvent('heroshield:init', src, token, HS.isAdmin(src), Config.Detections, grace)
    TriggerClientEvent('heroshield:config', src, nil, nil, { settings = Config.Settings, weapons = Config.BlacklistedWeapons })
    HS.api('/player', { event = 'join', player = GetPlayerName(src), identifier = HS.license(src) })
end

RegisterNetEvent('heroshield:ready', function()
    local src = source
    if HS.players[src] then return end
    register(src)
    HS.event('Join', 'Player joined', 'Joined the server', src)
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local p = HS.players[src]
    if p then
        HS.event('Leave', 'Player left', ('Reason: %s | Played: %dm'):format(tostring(reason or '?'), math.floor((os.time() - p.joined) / 60)), src)
        HS.api('/player', { event = 'leave', player = GetPlayerName(src) or '?',
            identifier = HS.license(src), playtime = os.time() - p.joined })
    end
    HS.players[src] = nil
end)

-- Resource restart: register players already online
CreateThread(function()
    Wait(2000)
    for _, s in ipairs(GetPlayers()) do
        local src = tonumber(s)
        if src and not HS.players[src] then register(src, 5) end
    end
end)

function HS.valid(src, token)
    local p = HS.players[src]
    if not p then return false end
    if p.token ~= token then
        HS.detect(src, 'Injection', 'invalid token')
        return false
    end
    return true
end

RegisterNetEvent('heroshield:hb', function(token)
    local src = source
    if HS.valid(src, token) then HS.players[src].lastHb = os.time() end
end)

RegisterNetEvent('heroshield:detect', function(token, name, info)
    local src = source
    if type(name) ~= 'string' or not Config.Detections[name] then return end
    if HS.valid(src, token) then HS.detect(src, name, info) end
end)

RegisterNetEvent('heroshield:resources', function(token, list)
    local src = source
    if type(list) ~= 'table' or not HS.valid(src, token) then return end
    local p = HS.players[src]
    for _, r in ipairs(list) do
        if type(r) == 'string' and r:sub(1, 1) ~= '_' and GetResourceState(r) == 'missing' then
            -- must be seen twice in a row
            if p.badResource == r then return HS.detect(src, 'Injection', 'unknown resource: ' .. r) end
            p.badResource = r
            return
        end
    end
    p.badResource = nil
end)

-- Anti-cheat stopped on client = no heartbeat
CreateThread(function()
    while true do
        Wait(15000)
        if Config.Detections.Heartbeat.enabled then
            local now = os.time()
            for src, p in pairs(HS.players) do
                local late = now - p.lastHb
                if not p.punished and late > HS.value('Heartbeat') then
                    HS.detect(src, 'Heartbeat', ('no heartbeat for %ds'):format(late))
                end
            end
        end
    end
end)

