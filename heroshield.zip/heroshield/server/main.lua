-- force = true skips the admin check (used for Config.AdminNoBypass detections)
function HS.punish(src, reason, info, action, force)
    src = tonumber(src)
    if not src or not GetPlayerName(src) then return end
    if not force and HS.isAdmin(src) then
        HS.log('admin ignored:', GetPlayerName(src), reason)
        return
    end
    local p = HS.players[src]
    if p and p.punished then return end
    if p and action ~= 'log' then p.punished = true end

    local target = HS.playerCard(src)
    target.reason, target.detail = reason, tostring(info or '-')
    local idents = GetPlayerIdentifiers(src)

    HS.log(target.name, reason, info, action)
    HS.api('/detection', { player = target.name, identifier = target.license, reason = reason,
        info = target.detail, action = action, identifiers = idents })

    if action == 'log' then
        HS.print('Detection', ('%s (%d) - %s %s'):format(target.name, src, reason, target.detail))
        return HS.punishEmbed('log', target)
    end

    if action == 'ban' then
        local banId = HS.addBan(src, target.name, reason, info)
        target.id = banId
        HS.print('Ban', ('%s (%d) banned - %s [%s]'):format(target.name, src, reason, banId))
        HS.api('/ban', { banId = banId, player = target.name, identifier = target.license,
            reason = reason, info = target.detail, identifiers = idents })
        HS.collectProof(src, banId,
            function(image) HS.punishEmbed('ban', target, image) end,
            function()
                if GetPlayerName(src) then DropPlayer(src, Config.BanMessage:format(reason, banId)) end
            end)
    else
        HS.print('Kick', ('%s (%d) kicked - %s'):format(target.name, src, reason))
        HS.punishEmbed('kick', target)
        SetTimeout(2000, function()
            if GetPlayerName(src) then DropPlayer(src, Config.KickMessage:format(reason)) end
        end)
    end
end

function HS.detect(src, name, info)
    local d = Config.Detections[name]
    if not d or not d.enabled then return end
    if HS.isAdmin(src) then
        if not Config.AdminNoBypass[name] then return end
        return HS.punish(src, name, info, d.action, true)
    end
    HS.punish(src, name, info, d.action)
end

exports('BanPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'ban') end)
exports('KickPlayer', function(src, reason) HS.punish(src, reason or 'Manual', 'export', 'kick') end)
exports('IsAdmin', function(src) return HS.isAdmin(src) end)

-- Ban check on connect
AddEventHandler('playerConnecting', function(_, _, deferrals)
    local src = source
    deferrals.defer()
    Wait(0)
    deferrals.update('HeRo Shield - checking...')
    local b = HS.findBan(HS.ids(src))
    if b then
        deferrals.done(Config.BanMessage:format(b.reason, b.id))
    else
        deferrals.done()
    end
end)

local function register(src)
    local token = HS.newToken()
    HS.players[src] = { token = token, lastHb = os.time(), joined = os.time(), expl = {}, ents = {} }
    TriggerClientEvent('heroshield:init', src, token, HS.isAdmin(src), Config.Detections)
    HS.api('/player', { event = 'join', player = GetPlayerName(src), identifier = HS.license(src) })
end

RegisterNetEvent('heroshield:ready', function()
    local src = source
    if HS.players[src] then return end
    register(src)
    HS.event('Join', 'Player joined', 'Joined the server', src)
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local p = HS.players[src]
    if p then
        HS.event('Leave', 'Player left', ('Reason: %s | Played: %dm'):format(tostring(reason or '?'), math.floor((os.time() - p.joined) / 60)), src)
        HS.api('/player', { event = 'leave', player = GetPlayerName(src) or '?',
            identifier = HS.license(src), playtime = os.time() - p.joined })
    end
    HS.players[src] = nil
end)

-- Resource restart: register players already online
CreateThread(function()
    Wait(2000)
    for _, s in ipairs(GetPlayers()) do
        local src = tonumber(s)
        if src and not HS.players[src] then register(src) end
    end
end)

function HS.valid(src, token)
    local p = HS.players[src]
    if not p then return false end
    if p.token ~= token then
        HS.detect(src, 'Injection', 'invalid token')
        return false
    end
    return true
end

RegisterNetEvent('heroshield:hb', function(token)
    local src = source
    if HS.valid(src, token) then HS.players[src].lastHb = os.time() end
end)

RegisterNetEvent('heroshield:detect', function(token, name, info)
    local src = source
    if type(name) ~= 'string' or not Config.Detections[name] then return end
    if HS.valid(src, token) then HS.detect(src, name, info) end
end)

RegisterNetEvent('heroshield:resources', function(token, list)
    local src = source
    if type(list) ~= 'table' or not HS.valid(src, token) then return end
    local p = HS.players[src]
    for _, r in ipairs(list) do
        if type(r) == 'string' and r:sub(1, 1) ~= '_' and GetResourceState(r) == 'missing' then
            -- must be seen twice in a row
            if p.badResource == r then return HS.detect(src, 'Injection', 'unknown resource: ' .. r) end
            p.badResource = r
            return
        end
    end
    p.badResource = nil
end)

-- Anti-cheat stopped on client = no heartbeat
CreateThread(function()
    while true do
        Wait(15000)
        if Config.Detections.Heartbeat.enabled then
            local now = os.time()
            for src, p in pairs(HS.players) do
                local late = now - p.lastHb
                if not p.punished and late > HS.value('Heartbeat') then
                    HS.detect(src, 'Heartbeat', ('no heartbeat for %ds'):format(late))
                end
            end
        end
    end
end)

