-- Detects the framework and checks admins (admins are never punished)
local fw = Config.Framework
local core

local function exists(res)
    return GetResourceState(res) ~= 'missing'
end

if fw == 'auto' then
    if exists('qbx_core') then fw = 'qbox'
    elseif exists('qb-core') then fw = 'qb'
    elseif exists('es_extended') then fw = 'esx'
    else fw = 'standalone' end
end
HS.framework = fw

local function getCore()
    if core then return core end
    local ok, obj = pcall(function()
        if fw == 'esx' then return exports['es_extended']:getSharedObject() end
        if fw == 'qb' then return exports['qb-core']:GetCoreObject() end
    end)
    if ok then core = obj end
    return core
end

local adminIds = {}
for _, id in ipairs(Config.AdminIdentifiers) do adminIds[id] = true end

local function frameworkAdmin(src)
    if fw == 'esx' then
        local ESX = getCore()
        local xPlayer = ESX and ESX.GetPlayerFromId(src)
        if xPlayer then
            local group = xPlayer.getGroup()
            for _, g in ipairs(Config.AdminGroups) do
                if g == group then return true end
            end
        end
    elseif fw == 'qb' then
        local QBCore = getCore()
        if QBCore then
            for _, g in ipairs(Config.AdminGroups) do
                if QBCore.Functions.HasPermission(src, g) then return true end
            end
        end
    elseif fw == 'qbox' then
        for _, g in ipairs(Config.AdminGroups) do
            local ok, res = pcall(function() return exports.qbx_core:HasPermission(src, g) end)
            if ok and res then return true end
        end
    end
    return false
end

function HS.isAdmin(src)
    src = tonumber(src)
    if not src or src == 0 then return true end
    if IsPlayerAceAllowed(src, Config.AdminAce) then return true end
    for _, g in ipairs(Config.AdminGroups) do
        if IsPlayerAceAllowed(src, 'group.' .. g) then return true end
    end
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if adminIds[id] then return true end
    end
    local ok, res = pcall(frameworkAdmin, src)
    return ok and res == true
end

CreateThread(function()
    Wait(1000)
    print(('^5[HeRo Shield]^7 Framework: ^2%s^7'):format(fw))
end)
