-- Server logs: console + Discord + dashboard
local COLORS = {
    Startup = 3447003, ResourceStart = 5763719, ResourceStop = 15548997, Join = 5763719, Leave = 9807270,
    Death = 15548997, Revive = 5793266, Weapon = 16705372, Explosion = 15105570, Admin = 10181046,
}

local queue = {}

local function playerInfo(src)
    if not src or not GetPlayerName(src) then return nil, nil end
    return ('%s (%d)'):format(GetPlayerName(src), src), HS.license(src)
end

-- HS.event('Death', 'Player died', 'Killed by X', src)
function HS.event(category, title, message, src)
    if not Config.Logs[category] then return end
    local player, identifier = playerInfo(src)

    HS.print('Logs', ('%s%s - %s'):format(player and (player .. ' | ') or '', title, (tostring(message or ''):gsub('\n', ' | '))))

    local EMOJI = { Startup = '🛡️', ResourceStart = '🟢', ResourceStop = '🔴', Join = '📥', Leave = '📤',
        Death = '💀', Revive = '💉', Weapon = '🔫', Explosion = '💥', Admin = '👮' }
    local e = HS.embedBase(('%s %s'):format(EMOJI[category] or '📋', title), COLORS[category] or 3447003)
    e.thumbnail = nil
    e.fields = {}
    if player then
        e.fields[#e.fields + 1] = { name = '👤 Player', value = player, inline = true }
        e.fields[#e.fields + 1] = { name = '🔑 License', value = ('`%s`'):format(identifier or '-'), inline = true }
    end
    e.fields[#e.fields + 1] = { name = '📝 Details', value = ('```%s```'):format(tostring(message or '-'):sub(1, 900)) }
    e.author.name = 'HeRo Shield • Logs'
    HS.sendEmbed(e, HS.webhook('Logs'))

    if HS.dashboardOn() then
        queue[#queue + 1] = {
            category = category, title = title, message = tostring(message or ''),
            player = player or '', identifier = identifier or '',
        }
    end
end

-- Send logs to the dashboard every 5 seconds (max 50 per request)
CreateThread(function()
    while true do
        Wait(2000)
        if #queue > 0 then
            local batch = {}
            for i = 1, math.min(50, #queue) do batch[i] = table.remove(queue, 1) end
            HS.api('/log', { logs = batch })
        end
        if #queue > 500 then queue = {} end
    end
end)

-- Resources
AddEventHandler('onResourceStart', function(res)
    if res == HS.RES then return end
    HS.event('ResourceStart', 'Resource started', res)
end)

AddEventHandler('onResourceStop', function(res)
    if res == HS.RES then
        HS.print('System', 'HeRo Shield stopped. Your server is NOT protected!')
        local e = HS.embedBase('🔴 Anti-cheat stopped', 15548997)
        e.description = 'HeRo Shield was stopped. **Your server is not protected.**'
        HS.sendEmbed(e, HS.webhook('Logs'))
        return
    end
    HS.event('ResourceStop', 'Resource stopped', res)
end)

-- Every explosion (off by default)
AddEventHandler('explosionEvent', function(src, ev)
    src = tonumber(src)
    if src and HS.players[src] then
        HS.event('Explosion', 'Explosion', ('Type %s'):format(tostring(ev.explosionType)), src)
    end
end)

-- From the client: death, revive, new weapon
local lastLog = {}
RegisterNetEvent('heroshield:log', function(token, kind, data)
    local src = source
    if type(kind) ~= 'string' or type(data) ~= 'table' or not HS.valid(src, token) then return end

    -- max 10 logs per 10 seconds per player
    lastLog[src] = lastLog[src] or {}
    if HS.rate(lastLog[src], 10, 10) then return end

    if kind == 'death' then
        local killer = tonumber(data.killer) or 0
        local weapon = tostring(data.weapon or '?'):sub(1, 40)
        if killer > 0 and killer ~= src and GetPlayerName(killer) then
            HS.event('Death', 'Player killed', ('Killed by %s (%d) with %s'):format(GetPlayerName(killer), killer, weapon), src)
        else
            HS.event('Death', 'Player died', ('Cause: %s'):format(weapon), src)
        end
    elseif kind == 'revive' then
        HS.event('Revive', 'Player revived', 'Player is alive again', src)
    elseif kind == 'weapon' then
        HS.event('Weapon', 'New weapon', tostring(data.weapon or '?'):sub(1, 40), src)
    end
end)

AddEventHandler('playerDropped', function()
    lastLog[source] = nil
end)
