-- Live stream: asks the website for an upload link, then tells the player to stream
function HS.startStream(src, identifier)
    HS.api('/stream', { action = 'open', identifier = identifier }, function(code, res)
        if code == 200 and res and res.url and GetPlayerName(src) then
            TriggerClientEvent('heroshield:stream', src, res.url)
        else
            HS.print('Error', ('Could not open live stream (HTTP %s)'):format(tostring(code)))
        end
    end)
end
