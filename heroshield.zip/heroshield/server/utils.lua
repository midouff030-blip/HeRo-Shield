HS = {
    RES     = GetCurrentResourceName(),
    VERSION = '1.3.0',
    players = {},
    bans    = {},
}

math.randomseed(os.time())

local TAG_COLORS = { Auth = '^4', Version = '^5', Webhook = '^3', System = '^2', Framework = '^6',
    Ban = '^1', Kick = '^3', Detection = '^1', Dashboard = '^4', Logs = '^5', Error = '^1', Debug = '^9' }

-- (HeRo Shield): [Tag] >> message
function HS.print(tag, msg)
    print(('^5(HeRo Shield)^7: %s[%s]^7 >> %s^7'):format(TAG_COLORS[tag] or '^7', tag, msg))
end

function HS.log(...)
    if not Config.Debug then return end
    local parts = {}
    for _, v in ipairs({ ... }) do parts[#parts + 1] = tostring(v) end
    HS.print('Debug', table.concat(parts, ' '))
end

function HS.ids(src)
    local t = {}
    for _, id in ipairs(GetPlayerIdentifiers(src)) do t[#t + 1] = id end
    for i = 0, (GetNumPlayerTokens(src) or 0) - 1 do
        local tok = GetPlayerToken(src, i)
        if tok then t[#t + 1] = 'token:' .. tok end
    end
    return t
end

function HS.license(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'license:' then return id end
    end
    return GetPlayerIdentifiers(src)[1] or ('src:' .. src)
end

function HS.genId()
    local chars, id = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 'HS-'
    for _ = 1, 6 do
        local n = math.random(#chars)
        id = id .. chars:sub(n, n)
    end
    return id
end

function HS.newToken()
    return ('%x%x%x'):format(math.random(0x10000000, 0x7fffffff), os.time(), math.random(0x10000000, 0x7fffffff))
end

-- true if more than max hits in window seconds
function HS.rate(list, window, max)
    local now, n = os.time(), 0
    for i = #list, 1, -1 do
        if now - list[i] >= window then table.remove(list, i) else n = n + 1 end
    end
    list[#list + 1] = now
    return n + 1 > max
end

function HS.value(name)
    return tonumber(Config.Detections[name].value) or 0
end

function HS.discord(title, desc, color, webhook)
    webhook = webhook or Config.Webhook
    if not webhook or webhook == '' then return end
    PerformHttpRequest(webhook, function() end, 'POST', json.encode({
        username = 'HeRo Shield',
        embeds = {{
            title = title, description = desc, color = color or 16711680,
            footer = { text = 'HeRo Shield • ' .. os.date('%d/%m/%Y %H:%M:%S') },
        }},
    }), { ['Content-Type'] = 'application/json' })
end
