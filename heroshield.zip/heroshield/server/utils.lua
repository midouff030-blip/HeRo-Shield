HS = {
    RES     = GetCurrentResourceName(),
    VERSION = '1.2.0',
    players = {},
    bans    = {},
}

math.randomseed(os.time())

function HS.log(...)
    if Config.Debug then print('^5[HeRo Shield]^7', ...) end
end

function HS.ids(src)
    local t = {}
    for _, id in ipairs(GetPlayerIdentifiers(src)) do t[#t + 1] = id end
    for i = 0, (GetNumPlayerTokens(src) or 0) - 1 do
        local tok = GetPlayerToken(src, i)
        if tok then t[#t + 1] = 'token:' .. tok end
    end
    return t
end

function HS.license(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'license:' then return id end
    end
    return GetPlayerIdentifiers(src)[1] or ('src:' .. src)
end

function HS.genId()
    local chars, id = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 'HS-'
    for _ = 1, 6 do
        local n = math.random(#chars)
        id = id .. chars:sub(n, n)
    end
    return id
end

function HS.newToken()
    return ('%x%x%x'):format(math.random(0x10000000, 0x7fffffff), os.time(), math.random(0x10000000, 0x7fffffff))
end

-- true if more than max hits in window seconds
function HS.rate(list, window, max)
    local now, n = os.time(), 0
    for i = #list, 1, -1 do
        if now - list[i] >= window then table.remove(list, i) else n = n + 1 end
    end
    list[#list + 1] = now
    return n + 1 > max
end

function HS.value(name)
    return tonumber(Config.Detections[name].value) or 0
end

function HS.discord(title, desc, color)
    if not Config.Webhook or Config.Webhook == '' then return end
    PerformHttpRequest(Config.Webhook, function() end, 'POST', json.encode({
        username = 'HeRo Shield',
        embeds = {{
            title = title, description = desc, color = color or 16711680,
            footer = { text = 'HeRo Shield • ' .. os.date('%d/%m/%Y %H:%M:%S') },
        }},
    }), { ['Content-Type'] = 'application/json' })
end
