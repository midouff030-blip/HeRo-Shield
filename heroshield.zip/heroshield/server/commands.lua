local function reply(src, msg)
    if src == 0 then
        print(msg)
    else
        TriggerClientEvent('chat:addMessage', src, { args = { 'HeRo Shield', (msg:gsub('%^%d', '')) } })
    end
end

RegisterCommand('hsban', function(src, args)
    if not HS.isAdmin(src) then return end
    local target = tonumber(args[1])
    if not target or not GetPlayerName(target) then return reply(src, 'Usage: hsban [id] [reason]') end
    if HS.isAdmin(target) then return reply(src, 'You cannot ban an admin.') end
    table.remove(args, 1)
    HS.punish(target, #args > 0 and table.concat(args, ' ') or 'Manual ban', 'admin', 'ban')
    reply(src, 'Player ' .. target .. ' banned.')
end, false)

RegisterCommand('hskick', function(src, args)
    if not HS.isAdmin(src) then return end
    local target = tonumber(args[1])
    if not target or not GetPlayerName(target) then return reply(src, 'Usage: hskick [id] [reason]') end
    if HS.isAdmin(target) then return reply(src, 'You cannot kick an admin.') end
    table.remove(args, 1)
    HS.punish(target, #args > 0 and table.concat(args, ' ') or 'Manual kick', 'admin', 'kick')
end, false)

RegisterCommand('hsunban', function(src, args)
    if not HS.isAdmin(src) then return end
    local b = HS.removeBan(args[1])
    if not b then return reply(src, 'Ban ID not found: ' .. tostring(args[1])) end
    reply(src, ('Unbanned %s (%s)'):format(b.id, b.name))
    HS.discord('Unban', ('%s (%s)'):format(b.id, b.name), 65280)
    HS.api('/unban', { banId = b.id })
end, false)

RegisterCommand('hsbans', function(src)
    if not HS.isAdmin(src) then return end
    reply(src, ('%d bans'):format(#HS.bans))
    for _, b in ipairs(HS.bans) do
        reply(src, ('%s | %s | %s | %s'):format(b.id, b.name, b.reason, b.date))
    end
end, false)
