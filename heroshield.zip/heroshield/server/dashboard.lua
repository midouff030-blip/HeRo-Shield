local lastSettings = ''

local function enabled()
    return Config.DashboardURL ~= '' and Config.LicenseKey ~= ''
end

function HS.api(path, data, cb)
    if not enabled() then return end
    PerformHttpRequest(Config.DashboardURL .. path, function(code, body)
        if code < 200 or code > 299 then HS.log('dashboard', path, 'HTTP', code) end
        if cb then
            local ok, res = pcall(json.decode, body or '')
            cb(code, ok and res or nil)
        end
    end, data and 'POST' or 'GET', data and json.encode(data) or '', {
        ['Content-Type'] = 'application/json',
        ['x-license'] = Config.LicenseKey,
    })
end

-- Settings sent from the dashboard
function HS.applySettings(s)
    if type(s) ~= 'table' then return end
    local raw = json.encode(s)
    if raw == lastSettings then return end
    lastSettings = raw

    if type(s.webhook) == 'string' and s.webhook ~= '' then Config.Webhook = s.webhook end

    if type(s.detections) == 'table' then
        for name, d in pairs(s.detections) do
            local c = Config.Detections[name]
            if c and type(d) == 'table' then
                if type(d.enabled) == 'boolean' then c.enabled = d.enabled end
                if d.action == 'ban' or d.action == 'kick' or d.action == 'log' then c.action = d.action end
                if c.value and tonumber(d.value) then c.value = tonumber(d.value) end
            end
        end
    end

    for src in pairs(HS.players) do
        TriggerClientEvent('heroshield:config', src, Config.Detections, HS.isAdmin(src))
    end
    print('^2[HeRo Shield]^7 Settings updated from dashboard.')
end

CreateThread(function()
    Wait(3000)
    if not enabled() then
        print('^3[HeRo Shield]^7 Dashboard off (no LicenseKey in shared/config.lua).')
        return
    end
    HS.api('/sync', nil, function(code)
        if code == 200 then
            print('^2[HeRo Shield]^7 Connected to dashboard.')
        elseif code == 401 then
            print('^1[HeRo Shield]^7 Invalid license key.')
        else
            print('^3[HeRo Shield]^7 Dashboard unreachable (HTTP ' .. tostring(code) .. ').')
        end
    end)
end)
