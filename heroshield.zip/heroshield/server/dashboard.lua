local lastSettings = ''

-- Accepts 'https://site.com', 'https://site.com/' or 'https://site.com/api'
local function baseUrl()
    local url = tostring(Config.DashboardURL or ''):gsub('%s', ''):gsub('/+$', '')
    if url ~= '' and not url:find('/api$') then url = url .. '/api' end
    return url
end
HS.baseUrl = baseUrl

local function enabled()
    return baseUrl() ~= '' and tostring(Config.LicenseKey or ''):gsub('%s', '') ~= ''
end

function HS.dashboardOn()
    return enabled()
end

function HS.api(path, data, cb)
    if not enabled() then return end
    PerformHttpRequest(baseUrl() .. path, function(code, body)
        if code < 200 or code > 299 then HS.log('dashboard', path, 'HTTP', code) end
        if cb then
            local ok, res = pcall(json.decode, body or '')
            cb(code, ok and res or nil)
        end
    end, data and 'POST' or 'GET', data and json.encode(data) or '', {
        ['Content-Type'] = 'application/json',
        ['x-license'] = (tostring(Config.LicenseKey):gsub('%s', '')),
    })
end

-- Settings sent from the dashboard
function HS.applySettings(s)
    if type(s) ~= 'table' then return end
    local raw = json.encode(s)
    if raw == lastSettings then return end
    lastSettings = raw

    if type(s.webhook) == 'string' and s.webhook ~= '' then Config.Webhook = s.webhook end
    if type(s.logWebhook) == 'string' and s.logWebhook ~= '' then Config.LogWebhook = s.logWebhook end
    if type(s.logs) == 'table' then
        for name, on in pairs(s.logs) do
            if Config.Logs[name] ~= nil and type(on) == 'boolean' then Config.Logs[name] = on end
        end
    end

    if type(s.detections) == 'table' then
        for name, d in pairs(s.detections) do
            local c = Config.Detections[name]
            if c and type(d) == 'table' then
                if type(d.enabled) == 'boolean' then c.enabled = d.enabled end
                if d.action == 'ban' or d.action == 'kick' or d.action == 'log' then c.action = d.action end
                if c.value and tonumber(d.value) then c.value = tonumber(d.value) end
            end
        end
    end

    for src in pairs(HS.players) do
        TriggerClientEvent('heroshield:config', src, Config.Detections, HS.isAdmin(src))
    end
    HS.print('Dashboard', 'Settings updated from the dashboard.')
end
