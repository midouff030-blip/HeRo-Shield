-- Server checks: the server sees these events before other players do, cheats cannot hide them.

local function enabled(name) return Config.Detections[name] and Config.Detections[name].enabled end

local function counter(src, key)
    local p = HS.players[src]
    if not p then return nil end
    p.rates = p.rates or {}
    p.rates[key] = p.rates[key] or {}
    return p.rates[key]
end

-- Is this network id a ped of ANOTHER player?
local function otherPlayerPed(src, netId)
    if not netId or netId == 0 then return nil end
    local ent = NetworkGetEntityFromNetworkId(netId)
    if not ent or ent == 0 or not DoesEntityExist(ent) or GetEntityType(ent) ~= 1 then return nil end
    if not IsPedAPlayer(ent) then return nil end
    local owner = NetworkGetEntityOwner(ent)
    if owner and owner ~= src then return owner end
end

-- Blacklisted events (honeypots)
for _, ev in ipairs(Config.BlacklistedEvents) do
    RegisterNetEvent(ev, function()
        local src = source
        if src and src > 0 then HS.detect(src, 'BlacklistedEvent', ev) end
    end)
end

-- Event spam on HeRo Shield events
local spam = {}
CreateThread(function()
    while true do
        Wait(1000)
        spam = {}
    end
end)

for _, ev in ipairs({ 'heroshield:hb', 'heroshield:detect', 'heroshield:resources', 'heroshield:ready', 'heroshield:log' }) do
    AddEventHandler(ev, function()
        local src = source
        if not src or src <= 0 or not enabled('EventSpam') then return end
        spam[src] = (spam[src] or 0) + 1
        if spam[src] > HS.value('EventSpam') then HS.detect(src, 'EventSpam', ev) end
    end)
end

-- Explosions
AddEventHandler('explosionEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('Explosion') then return end

    -- scaled explosions only come from menus
    if ev.damageScale and ev.damageScale > 1.0 then
        CancelEvent()
        return HS.detect(src, 'Explosion', ('boosted explosion x%.1f (type %s)'):format(ev.damageScale, tostring(ev.explosionType)))
    end
    -- hidden explosions: blocked + logged, never a ban on their own
    if ev.isInvisible and ev.isAudible == false then
        CancelEvent()
        HS.log('hidden explosion blocked', src, ev.explosionType)
    end
    if HS.rate(counter(src, 'expl'), 10, HS.value('Explosion')) then
        CancelEvent()
        HS.detect(src, 'Explosion', ('explosion spam (type %s)'):format(tostring(ev.explosionType)))
    end
end)

-- Fire
AddEventHandler('fireEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('FireSpam') then return end
    local list = counter(src, 'fire')
    local count = (type(ev) == 'table' and type(ev.fires) == 'table') and #ev.fires or 1
    for _ = 1, math.max(1, count) do
        if HS.rate(list, 10, HS.value('FireSpam')) then
            CancelEvent()
            return HS.detect(src, 'FireSpam', ('%d fires'):format(count))
        end
    end
end)

-- Particles
AddEventHandler('ptFxEvent', function(src)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('ParticleSpam') then return end
    if HS.rate(counter(src, 'ptfx'), 10, HS.value('ParticleSpam')) then
        CancelEvent()
        HS.detect(src, 'ParticleSpam', 'particle spam')
    end
end)

-- Projectiles
AddEventHandler('startProjectileEvent', function(src)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('ProjectileSpam') then return end
    if HS.rate(counter(src, 'proj'), 10, HS.value('ProjectileSpam')) then
        CancelEvent()
        HS.detect(src, 'ProjectileSpam', 'projectile spam')
    end
end)

-- Giving weapons to another player
AddEventHandler('giveWeaponEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('GiveWeaponOther') or ev.givenAsPickup then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'GiveWeaponOther', ('gave weapon %s to player %d'):format(tostring(ev.weaponType), target))
    end
end)

-- Removing weapons of another player
local function removeWeapons(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('RemoveWeaponOther') then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'RemoveWeaponOther', ('removed weapons of player %d'):format(target))
    end
end
AddEventHandler('removeWeaponEvent', removeWeapons)
AddEventHandler('removeAllWeaponsEvent', removeWeapons)

-- Clearing tasks of another player (kick out of car, freeze, ...)
AddEventHandler('clearPedTasksEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('ClearTasksOther') then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'ClearTasksOther', ('cleared tasks of player %d'):format(target))
    end
end)

-- Entities
local badModels = {}
for _, m in ipairs(Config.BlacklistedModels) do badModels[GetHashKey(m)] = m end

AddEventHandler('entityCreating', function(ent)
    if not DoesEntityExist(ent) then return end
    local owner = NetworkGetEntityOwner(ent)
    if not owner or not HS.players[owner] then return end

    -- blacklisted model
    local model = GetEntityModel(ent)
    if enabled('BlacklistedEntity') and badModels[model] then
        CancelEvent()
        return HS.detect(owner, 'BlacklistedEntity', badModels[model])
    end

    -- entity created by a resource that does not exist on the server = injected menu
    if enabled('EntityInjection') then
        local script = GetEntityScript(ent)
        if script and script ~= '' and GetResourceState(script) == 'missing' then
            CancelEvent()
            return HS.detect(owner, 'EntityInjection', ('spawned by unknown resource "%s"'):format(script))
        end
    end

    -- too many script entities
    if enabled('EntitySpam') and GetEntityPopulationType(ent) == 7 then
        if HS.rate(counter(owner, 'ents'), 10, HS.value('EntitySpam')) then
            CancelEvent()
            HS.detect(owner, 'EntitySpam', 'entity spam')
        end
    end
end)

-- Weapon damage
AddEventHandler('weaponDamageEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('WeaponDamage') then return end
    local dmg = tonumber(ev.weaponDamage) or 0
    if dmg > HS.value('WeaponDamage') then
        CancelEvent()
        HS.detect(src, 'WeaponDamage', ('damage %d (weapon %s)'):format(dmg, tostring(ev.weaponType)))
    end
end)
