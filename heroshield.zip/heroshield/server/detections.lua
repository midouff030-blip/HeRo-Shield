-- Blacklisted events
for _, ev in ipairs(Config.BlacklistedEvents) do
    RegisterNetEvent(ev, function()
        local src = source
        if src and src > 0 then HS.detect(src, 'BlacklistedEvent', ev) end
    end)
end

-- Event spam
local spam = {}
CreateThread(function()
    while true do
        Wait(1000)
        spam = {}
    end
end)

for _, ev in ipairs({ 'heroshield:hb', 'heroshield:detect', 'heroshield:resources', 'heroshield:ready', 'heroshield:log', 'heroshield:upload' }) do
    AddEventHandler(ev, function()
        local src = source
        if not src or src <= 0 or not Config.Detections.EventSpam.enabled then return end
        spam[src] = (spam[src] or 0) + 1
        if spam[src] > HS.value('EventSpam') then HS.detect(src, 'EventSpam', ev) end
    end)
end

-- Explosions
AddEventHandler('explosionEvent', function(src, ev)
    src = tonumber(src)
    local p = src and HS.players[src]
    if not p or not Config.Detections.Explosion.enabled then return end

    if ev.isInvisible or ev.isAudible == false or (ev.damageScale and ev.damageScale > 1.0) then
        CancelEvent()
        return HS.detect(src, 'Explosion', ('hidden explosion (type %s)'):format(tostring(ev.explosionType)))
    end
    if HS.rate(p.expl, 10, HS.value('Explosion')) then
        CancelEvent()
        HS.detect(src, 'Explosion', ('explosion spam (type %s)'):format(tostring(ev.explosionType)))
    end
end)

-- Entities
local badModels = {}
for _, m in ipairs(Config.BlacklistedModels) do badModels[GetHashKey(m)] = m end

AddEventHandler('entityCreating', function(ent)
    if not DoesEntityExist(ent) then return end
    local owner = NetworkGetEntityOwner(ent)
    local p = owner and HS.players[owner]
    if not p then return end
    local model = GetEntityModel(ent)

    if Config.Detections.BlacklistedEntity.enabled and badModels[model] then
        CancelEvent()
        return HS.detect(owner, 'BlacklistedEntity', badModels[model])
    end

    if Config.Detections.EntitySpam.enabled and GetEntityPopulationType(ent) == 7 then
        if HS.rate(p.ents, 10, HS.value('EntitySpam')) then
            CancelEvent()
            HS.detect(owner, 'EntitySpam', 'entity spam')
        end
    end
end)

-- Weapon damage
AddEventHandler('weaponDamageEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not Config.Detections.WeaponDamage.enabled then return end
    local dmg = tonumber(ev.weaponDamage) or 0
    if dmg > HS.value('WeaponDamage') then
        CancelEvent()
        HS.detect(src, 'WeaponDamage', ('damage %d (weapon %s)'):format(dmg, tostring(ev.weaponType)))
    end
end)
