-- Server checks: the server sees these events before other players, cheats cannot hide them.

local function enabled(name) return Config.Detections[name] and Config.Detections[name].enabled end

local function counter(src, key)
    local p = HS.players[src]
    if not p then return nil end
    p.rates = p.rates or {}
    p.rates[key] = p.rates[key] or {}
    return p.rates[key]
end

-- Is this network id a ped of ANOTHER player?
local function otherPlayerPed(src, netId)
    if not netId or netId == 0 then return nil end
    local ent = NetworkGetEntityFromNetworkId(netId)
    if not ent or ent == 0 or not DoesEntityExist(ent) or GetEntityType(ent) ~= 1 then return nil end
    if not IsPedAPlayer(ent) then return nil end
    local owner = NetworkGetEntityOwner(ent)
    if owner and owner ~= src then return owner end
end

local function objectLog(src, title, info)
    local wh = HS.webhook('Object')
    if wh and wh ~= '' then
        local e = HS.embedBase('📦 ' .. title, 15105570)
        e.description = ('**Player:** %s (%d)\n```%s```'):format(GetPlayerName(src) or '?', src, info)
        HS.sendEmbed(e, wh)
    end
end

-- ===== Lists (rebuilt when changed from the dashboard) =====
local badModels, badWeapons, badExplosions, entityWhitelist = {}, {}, {}, {}
local registeredEvents = {}

function HS.rebuildLists()
    badModels, badWeapons, badExplosions, entityWhitelist = {}, {}, {}, {}
    for _, m in ipairs(Config.BlacklistedModels) do badModels[GetHashKey(m)] = m end
    for _, w in ipairs(Config.BlacklistedWeapons) do badWeapons[GetHashKey(w)] = w end
    for _, t in ipairs(Config.BlacklistedExplosions or {}) do badExplosions[tonumber(t)] = true end
    for _, r in ipairs(Config.EntityWhitelistScripts or {}) do entityWhitelist[r] = true end
    for _, ev in ipairs(Config.BlacklistedEvents) do
        if not registeredEvents[ev] then
            registeredEvents[ev] = true
            RegisterNetEvent(ev, function()
                local src = source
                if src and src > 0 and registeredEvents[ev] then HS.detect(src, 'BlacklistedEvent', ev) end
            end)
        end
    end
end
HS.rebuildLists()

-- ===== Event spam on HeRo Shield events =====
local spam = {}
CreateThread(function()
    while true do
        Wait(1000)
        spam = {}
    end
end)

for _, ev in ipairs({ 'heroshield:hb', 'heroshield:detect', 'heroshield:resources', 'heroshield:ready', 'heroshield:log', 'heroshield:report', 'heroshield:resstop' }) do
    AddEventHandler(ev, function()
        local src = source
        if not src or src <= 0 or not enabled('EventSpam') then return end
        spam[src] = (spam[src] or 0) + 1
        if spam[src] > HS.value('EventSpam') then HS.detect(src, 'EventSpam', ev) end
    end)
end

-- ===== Explosions =====
AddEventHandler('explosionEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] then return end
    local etype = tonumber(ev.explosionType) or -1

    if enabled('BlacklistedExplosion') and badExplosions[etype] then
        CancelEvent()
        return HS.detect(src, 'BlacklistedExplosion', ('explosion type %d'):format(etype))
    end
    if enabled('ExplosionScale') and ev.damageScale and ev.damageScale > HS.value('ExplosionScale') then
        CancelEvent()
        return HS.detect(src, 'ExplosionScale', ('damage scale x%.1f (type %d)'):format(ev.damageScale, etype))
    end
    if enabled('HiddenExplosion') and ev.isInvisible and ev.isAudible == false then
        CancelEvent()
        return HS.detect(src, 'HiddenExplosion', ('invisible + silent explosion (type %d)'):format(etype))
    end
    if enabled('Explosion') and HS.rate(counter(src, 'expl'), 10, HS.value('Explosion')) then
        CancelEvent()
        HS.detect(src, 'Explosion', ('explosion spam (type %d)'):format(etype))
    end
end)

-- ===== Fire / particles / projectiles =====
AddEventHandler('fireEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('FireSpam') then return end
    local count = (type(ev) == 'table' and type(ev.fires) == 'table') and #ev.fires or 1
    for _ = 1, math.max(1, count) do
        if HS.rate(counter(src, 'fire'), 10, HS.value('FireSpam')) then
            CancelEvent()
            return HS.detect(src, 'FireSpam', ('%d fires'):format(count))
        end
    end
end)

AddEventHandler('ptFxEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] then return end
    local scale = type(ev) == 'table' and tonumber(ev.scale) or nil
    if enabled('ParticleScale') and scale and scale > HS.value('ParticleScale') then
        CancelEvent()
        return HS.detect(src, 'ParticleScale', ('particle scale x%.1f'):format(scale))
    end
    if enabled('ParticleSpam') and HS.rate(counter(src, 'ptfx'), 10, HS.value('ParticleSpam')) then
        CancelEvent()
        HS.detect(src, 'ParticleSpam', 'particle spam')
    end
end)

AddEventHandler('startProjectileEvent', function(src)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('ProjectileSpam') then return end
    if HS.rate(counter(src, 'proj'), 10, HS.value('ProjectileSpam')) then
        CancelEvent()
        HS.detect(src, 'ProjectileSpam', 'projectile spam')
    end
end)

-- ===== Weapons on other players =====
AddEventHandler('giveWeaponEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('GiveWeaponOther') or ev.givenAsPickup then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'GiveWeaponOther', ('gave weapon %s to player %d'):format(tostring(ev.weaponType), target))
    end
end)

local function removeWeapons(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('RemoveWeaponOther') then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'RemoveWeaponOther', ('removed weapons of player %d'):format(target))
    end
end
AddEventHandler('removeWeaponEvent', removeWeapons)
AddEventHandler('removeAllWeaponsEvent', removeWeapons)

AddEventHandler('clearPedTasksEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] or not enabled('ClearTasksOther') then return end
    local target = otherPlayerPed(src, ev.pedId)
    if target then
        CancelEvent()
        HS.detect(src, 'ClearTasksOther', ('cleared tasks of player %d'):format(target))
    end
end)

-- ===== Entities =====
AddEventHandler('entityCreating', function(ent)
    if not DoesEntityExist(ent) then return end
    local owner = NetworkGetEntityOwner(ent)
    if not owner or not HS.players[owner] then return end

    local model = GetEntityModel(ent)
    if enabled('BlacklistedEntity') and badModels[model] then
        CancelEvent()
        objectLog(owner, 'Blacklisted entity blocked', badModels[model])
        return HS.detect(owner, 'BlacklistedEntity', badModels[model])
    end

    local script = GetEntityScript(ent)
    if enabled('EntityInjection') and script and script ~= '' and not entityWhitelist[script]
        and GetResourceState(script) == 'missing' then
        CancelEvent()
        objectLog(owner, 'Injected entity blocked', ('spawned by "%s"'):format(script))
        return HS.detect(owner, 'EntityInjection', ('spawned by unknown resource "%s"'):format(script))
    end

    if GetEntityPopulationType(ent) == 7 then
        local etype = GetEntityType(ent)
        local name, key = nil, nil
        if etype == 1 then name, key = 'PedSpam', 'peds'
        elseif etype == 2 then name, key = 'VehicleSpam', 'veh'
        elseif etype == 3 then name, key = 'ObjectSpam', 'obj' end
        if name and enabled(name) and HS.rate(counter(owner, key), 10, HS.value(name)) then
            CancelEvent()
            objectLog(owner, name .. ' blocked', ('model %s'):format(tostring(model)))
            return HS.detect(owner, name, name .. ' (spawn spam)')
        end
        if enabled('EntitySpam') and HS.rate(counter(owner, 'ents'), 10, HS.value('EntitySpam')) then
            CancelEvent()
            HS.detect(owner, 'EntitySpam', 'entity spam')
        end
    end
end)

-- ===== Damage / kills =====
AddEventHandler('weaponDamageEvent', function(src, ev)
    src = tonumber(src)
    if not src or not HS.players[src] then return end
    local dmg = tonumber(ev.weaponDamage) or 0

    if enabled('WeaponDamage') and dmg > HS.value('WeaponDamage') then
        CancelEvent()
        return HS.detect(src, 'WeaponDamage', ('damage %d (weapon %s)'):format(dmg, tostring(ev.weaponType)))
    end

    if ev.willKill then
        -- kill from too far away
        if enabled('MagicBullet') and ev.hitGlobalId then
            local target = NetworkGetEntityFromNetworkId(ev.hitGlobalId)
            local shooter = GetPlayerPed(src)
            if target and target ~= 0 and DoesEntityExist(target) and shooter and shooter ~= 0 then
                local dist = #(GetEntityCoords(target) - GetEntityCoords(shooter))
                if dist > HS.value('MagicBullet') then
                    CancelEvent()
                    return HS.detect(src, 'MagicBullet', ('kill at %.0fm (weapon %s)'):format(dist, tostring(ev.weaponType)))
                end
            end
        end
        -- too many kills
        if enabled('KillRate') and HS.rate(counter(src, 'kills'), 60, HS.value('KillRate')) then
            HS.detect(src, 'KillRate', ('more than %d kills in 1 minute'):format(HS.value('KillRate')))
        end
    end
end)

-- ===== Blacklisted weapon in hand (server-side) =====
CreateThread(function()
    while true do
        Wait(1000)
        if enabled('BlacklistedWeapon') then
            for src, p in pairs(HS.players) do
                if not p.punished then
                    local ped = GetPlayerPed(src)
                    if ped and ped ~= 0 then
                        local w = GetSelectedPedWeapon(ped)
                        if badWeapons[w] then
                            RemoveWeaponFromPed(ped, w)
                            HS.detect(src, 'BlacklistedWeapon', badWeapons[w])
                        end
                    end
                end
            end
        end
    end
end)
