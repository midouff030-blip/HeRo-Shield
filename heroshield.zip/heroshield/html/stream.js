// Live stream: game frames -> JPEG -> WebSocket -> dashboard
(function () {
  const view = document.getElementById('view');
  const out = document.getElementById('out');
  const octx = out.getContext('2d');
  let game = null, ws = null, timer = null, stopAt = 0, sending = false, cfg = {};

  function stop() {
    clearInterval(timer); timer = null;
    if (ws) { try { ws.close(); } catch (e) {} ws = null; }
  }

  function tick() {
    if (Date.now() > stopAt) return stop();
    if (!ws || ws.readyState !== 1 || sending || ws.bufferedAmount > 400000) return;
    game.draw();
    // WebGL frame is upside down -> flip into the 2D canvas
    octx.save();
    octx.scale(1, -1);
    octx.drawImage(view, 0, -out.height, out.width, out.height);
    octx.restore();
    sending = true;
    out.toBlob((blob) => {
      sending = false;
      if (blob && ws && ws.readyState === 1) ws.send(blob);
    }, 'image/jpeg', cfg.quality || 0.5);
  }

  function start(data) {
    cfg = data;
    stopAt = Date.now() + (data.duration || 60) * 1000;
    if (timer && ws && ws.readyState === 1) return; // already streaming, just extend
    stop();
    const w = data.width || 854, h = Math.round(w * 9 / 16);
    if (!game) game = window.createGameView(view);
    game.resize(w, h);
    out.width = w; out.height = h;
    ws = new WebSocket(data.url);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => { timer = setInterval(tick, Math.round(1000 / (data.fps || 10))); };
    ws.onmessage = (e) => { if (e.data === 'stop') stop(); };
    ws.onclose = () => { clearInterval(timer); timer = null; ws = null; };
  }

  window.addEventListener('message', (e) => {
    const d = e.data || {};
    if (d.action === 'hs:stream:start') start(d);
    if (d.action === 'hs:stream:stop') stop();
  });
})();

// NUI devtools detection: "debugger" only pauses when devtools are open
setInterval(() => {
  const t = performance.now();
  // eslint-disable-next-line no-debugger
  debugger;
  if (performance.now() - t > 150) {
    fetch(`https://${GetParentResourceName()}/devtools`, { method: 'POST', body: '{}' }).catch(() => {});
  }
}, 4000);
