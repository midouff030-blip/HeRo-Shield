# HeRo Shield v1.5.0

Free FiveM anti-cheat. Works with ESX, QBCore, Qbox and standalone.

## Install
1. Put `heroshield` in your `resources` folder (OneSync required).
2. Add to `server.cfg`:
```
ensure screencapture        # or screenshot-basic (screencapture fixes black screenshots)
ensure heroshield
add_ace group.admin heroshield.bypass allow

# Strongly recommended: blocks objects/vehicles spawned by menus
set sv_entityLockdown relaxed
set sv_filterRequestControl 4
```
3. Open the dashboard, add your server, copy the license key.
4. Paste it in `shared/config.lua` → `Config.LicenseKey`.
5. Restart the server.

Detections, logs and webhooks can be changed from the dashboard (Settings tab).

## Proof, replay & live view
Install `screencapture` (recommended, no black screens) or `screenshot-basic`, started before heroshield.
Images go to `Config.Screenshot.UploadUrl` (imgbb...) or to your dashboard if it is empty.
- Ban: screenshot + replay of the last 4 minutes, saved on the dashboard
- Live view: watch a player's screen from the dashboard (Players tab)
- Kick / ban online players from the dashboard

## Logs
Startup, resource start/stop, join/leave, deaths and kills, revives, new weapons, admin actions.
Sent to the console, the dashboard (Logs tab) and Discord.

## Admins
Admins are checked like everyone EXCEPT `Config.AdminAllowed` (noclip, godmode, invisible, spectate, freecam, vehicle boost, health/armor... = txAdmin and admin tools). Noclip / godmode / invisible / speed / superjump are only allowed while the txAdmin player mode is ON (`Config.AdminTxAdminOnly`): noclip from a cheat menu bans the admin. Everything else (blacklisted weapons, car/object spam, menus, injection...) bans admins too.
A player is admin if:
- he has the ACE `heroshield.bypass` or `group.admin` / `group.god` ...
- his framework group is in `Config.AdminGroups`
- his identifier is in `Config.AdminIdentifiers`

## Commands
`hsban [id] [reason]` · `hskick [id] [reason]` · `hsunban [ban id]` · `hsbans`

## Exports
`exports.heroshield:BanPlayer(src, reason)` · `KickPlayer(src, reason)` · `IsAdmin(src)`

## Tip
Set actions to `log` for 1-2 days first, then switch to `ban`.
