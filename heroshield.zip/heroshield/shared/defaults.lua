-- Default values (so an old config.lua still works)
local function def(t, defaults)
    for k, v in pairs(defaults) do
        if t[k] == nil then t[k] = v end
    end
    return t
end

Config.Settings = def(Config.Settings or {}, {
    DiscordInvite = '', RevealBanReason = true, TxAdminIntegration = true, BanIP = true,
    AntiVpn = false, RequireSteam = false, RequireDiscord = false, RequireNormalName = false,
})
Config.Webhook = Config.Webhook or ''
Config.Webhooks = def(Config.Webhooks or {}, { Ban = '', Kick = '', Warn = '', Object = '', Vpn = '', Logs = Config.LogWebhook or '' })
Config.BlacklistedExplosions = Config.BlacklistedExplosions or { 7, 29, 33, 37, 59, 82 }
Config.EntityWhitelistScripts = Config.EntityWhitelistScripts or {}
Config.AdminAllowed = Config.AdminAllowed or {}
Config.AdminTxAdminOnly = Config.AdminTxAdminOnly or {}
Config.Strikes = Config.Strikes or {}
Config.Screenshot = def(Config.Screenshot or {}, {
    Enabled = true, Resource = 'auto', UploadUrl = '', UploadField = 'image', Quality = 0.5, ProofShots = 2,
    ProofGap = 300, MaxWait = 3000, Replay = true, ReplayLength = 180, ReplayInterval = 8, ReplayQuality = 0.3,
    ReplayMaxWait = 10000, StreamQuality = 0.35, StreamMaxTime = 600,
})

Config.Stream = def(Config.Stream or {}, { Fps = 10, Width = 854, Quality = 0.5 })

-- every detection used by the code must exist (disabled if missing from an old config)
for _, name in ipairs({
    'GodMode', 'Invisible', 'HealthHack', 'ArmorHack', 'ShrinkPed', 'TeleportWaypoint', 'ChangePed', 'Spectate',
    'VisionHack', 'DamageModifier', 'SuperPunch', 'MagicBullet', 'KillRate', 'SpeedHack', 'SuperJump',
    'InfiniteStamina', 'NoClip', 'VehicleNoClip', 'FreeCam', 'VehicleBoost', 'BlacklistedWeapon', 'GiveWeaponOther',
    'RemoveWeaponOther', 'RapidFire', 'InfiniteAmmo', 'WeaponDamage', 'BlacklistedEvent', 'EventSpam',
    'ClearTasksOther', 'Injection', 'Heartbeat', 'BlacklistedEntity', 'EntityInjection', 'VehicleSpam', 'PedSpam',
    'ObjectSpam', 'EntitySpam', 'ParticleSpam', 'ParticleScale', 'Explosion', 'ExplosionScale', 'HiddenExplosion',
    'BlacklistedExplosion', 'FireSpam', 'ProjectileSpam',
}) do
    if not Config.Detections[name] then Config.Detections[name] = { enabled = false, action = 'log', value = 0 } end
end
