Config = {}

-- Framework: 'auto', 'esx', 'qb', 'qbox' or 'standalone'
Config.Framework = 'auto'

-- Dashboard (get your key on the website)
Config.LicenseKey   = 'HS-1BF1DC-ABC4F9-761D30-A6EF7A'
Config.DashboardURL = 'https://hero-shield.onrender.com'

-- Discord webhooks (empty = use Webhook). Can also be set from the dashboard.
Config.Webhook = 'https://discord.com/api/webhooks/1560220867353387011/_7R05mypC6pJpDPDxdXpSe8TxIm49eEs6AC_Z1V6pKYi8YRz1Sypyyr51XUYnlqpZvO0'
Config.Webhooks = {
    Ban    = '',   -- bans
    Kick   = '',   -- kicks
    Warn   = '',   -- 'log' detections
    Object = '',   -- spawned entities / objects blocked
    Vpn    = '',   -- VPN / connection refused
    Logs   = 'https://discord.com/api/webhooks/1560220867353387011/_7R05mypC6pJpDPDxdXpSe8TxIm49eEs6AC_Z1V6pKYi8YRz1Sypyyr51XUYnlqpZvO0',
}
Config.LogWebhook = Config.Webhooks.Logs

-- General settings (also in the dashboard: Configuration > Settings)
Config.Settings = {
    AntiSpoof = true,   -- refuse players without license / hardware ids
    DiscordInvite      = '',     -- shown on the ban screen
    RevealBanReason    = true,   -- show the real reason to the banned player
    TxAdminIntegration = true,   -- txAdmin noclip/godmode allowed for admins
    BanIP              = true,   -- also ban the IP address
    AntiVpn            = false,  -- refuse VPN / proxy / hosting IPs (ip-api.com)
    RequireSteam       = false,  -- Steam must be open
    RequireDiscord     = false,  -- Discord must be open
    RequireNormalName  = false,  -- no weird names (html, emojis, too short)
}

-- Admins (ACE, framework group or identifier)
Config.AdminAce         = 'heroshield.bypass'
Config.AdminGroups      = { 'god', 'superadmin', 'admin', 'mod' }
Config.AdminIdentifiers = {
    -- 'license:xxxxxxxx',
}
-- Admin tools allowed (everything else bans admins too)
Config.AdminAllowed = {
    NoClip = true, VehicleNoClip = true, GodMode = true, Invisible = true, SpeedHack = true, SuperJump = true,
    Spectate = true, FreeCam = true, VehicleBoost = true, HealthHack = true, ArmorHack = true,
    VisionHack = true, Heartbeat = true, TeleportWaypoint = true, InfiniteStamina = true, ChangePed = true,
}
-- Only allowed while the txAdmin mode is ON (cheat noclip = ban, even for admins)
Config.AdminTxAdminOnly = { NoClip = true, VehicleNoClip = true, GodMode = true, Invisible = true, SpeedHack = true, SuperJump = true }

-- Ban screen
Config.BanScreen = {
    Enabled    = true,
    ServerName = 'My Server',
    Logo       = '',
    Discord    = '',
    Website    = '',
    ShowProof  = true,
    Message    = 'If you feel this is an error, contact the server support.',
}

Config.BanMessage  = 'HeRo Shield | Banned: %s | Ban ID: %s'
Config.KickMessage = 'HeRo Shield | Kicked: %s'
Config.JoinGrace   = 15
Config.Debug       = false

-- Server logs
Config.Logs = {
    Startup = true, ResourceStart = true, ResourceStop = true, Join = true, Leave = true,
    Death = true, Revive = true, Weapon = true, Explosion = false, Admin = true,
}

-- Screenshots / proof / live stream (screencapture or screenshot-basic)
Config.Screenshot = {
    Enabled        = true,
    Resource       = 'auto',
    UploadUrl      = 'https://api.imgbb.com/1/upload?key=8d37a3833bf960e16a1bb98a08b15e50',
    UploadField    = 'image',
    Quality        = 0.5,
    ProofShots     = 2,
    ProofGap       = 300,
    MaxWait        = 3000,
    Replay         = true,
    ReplayLength   = 180,
    ReplayInterval = 8,
    ReplayQuality  = 0.3,
    ReplayMaxWait  = 10000,
    StreamQuality  = 0.35,    -- only used by the old HTTP stream fallback
    StreamMaxTime  = 600,     -- seconds max per stream
}

-- Live video (dashboard > Multi Stream). Needs the website hosted on Render (WebSocket).
Config.Stream = {
    Fps     = 10,     -- frames per second (5 - 20)
    Width   = 854,    -- 640 = 360p, 854 = 480p, 1280 = 720p
    Quality = 0.5,    -- 0.1 - 1.0
}

-- action: 'ban', 'kick' or 'log' (log = warn)
Config.Detections = {
    -- Client > Internal / Player / Combat / Vehicles (v2.2)
    LuaTamper            = { enabled = true, action = 'ban'  },               -- natives hooked by an injected menu
    LuaMenu              = { enabled = true, action = 'ban'  },               -- known Lua menu loaded
    ResourceStop         = { enabled = true, action = 'ban'  },               -- resource stopped on the player PC
    DevTools             = { enabled = true, action = 'kick' },               -- NUI devtools opened
    SemiGodMode          = { enabled = true, action = 'ban'  },               -- health restored right after a hit
    GhostMode            = { enabled = true, action = 'log'  },               -- almost transparent ped
    SilentAim            = { enabled = true, action = 'ban',  value = 2 },    -- different victims hit without line of sight (60s)
    AntiBurn             = { enabled = true, action = 'ban'  },               -- sets other players on fire
    XssExploit           = { enabled = true, action = 'kick' },               -- html in player name
    Hijack               = { enabled = true, action = 'log'  },               -- steals a player car instantly
    ThrowVehicle         = { enabled = true, action = 'ban',  value = 60 },   -- empty car faster than X m/s
    VehicleSpeedModifier = { enabled = true, action = 'log'  },               -- top speed modifier
    ChangePlate          = { enabled = true, action = 'log'  },               -- plate changed while driving

    -- Client > Player
    GodMode           = { enabled = true, action = 'ban'  },
    Invisible         = { enabled = true, action = 'kick' },
    HealthHack        = { enabled = true, action = 'ban'  },
    ArmorHack         = { enabled = true, action = 'ban'  },
    ShrinkPed         = { enabled = true, action = 'ban'  },
    TeleportWaypoint  = { enabled = true, action = 'ban'  },
    ChangePed         = { enabled = true, action = 'log'  },
    Spectate          = { enabled = true, action = 'ban'  },
    VisionHack        = { enabled = true, action = 'log'  },
    -- Client > Combat
    DamageModifier    = { enabled = true, action = 'ban'  },
    SuperPunch        = { enabled = true, action = 'ban'  },
    MagicBullet       = { enabled = true, action = 'log',  value = 350 },   -- max kill distance (m)
    KillRate          = { enabled = true, action = 'log',  value = 12 },    -- max kills per minute
    -- Movement
    SpeedHack         = { enabled = true, action = 'kick', value = 12 },
    SuperJump         = { enabled = true, action = 'kick', value = 4 },
    InfiniteStamina   = { enabled = true, action = 'log'  },
    NoClip            = { enabled = true, action = 'ban'  },
    VehicleNoClip     = { enabled = true, action = 'ban'  },
    FreeCam           = { enabled = true, action = 'kick', value = 120 },
    VehicleBoost      = { enabled = true, action = 'kick' },
    -- Weapons
    BlacklistedWeapon = { enabled = true, action = 'ban'  },
    GiveWeaponOther   = { enabled = true, action = 'ban'  },
    RemoveWeaponOther = { enabled = true, action = 'kick' },
    RapidFire         = { enabled = true, action = 'kick', value = 25 },    -- max shots per second
    InfiniteAmmo      = { enabled = true, action = 'log'  },
    WeaponDamage      = { enabled = true, action = 'log',  value = 300 },
    -- Events
    BlacklistedEvent  = { enabled = true, action = 'ban'  },
    EventSpam         = { enabled = true, action = 'kick', value = 40 },
    ClearTasksOther   = { enabled = true, action = 'kick' },
    Injection         = { enabled = true, action = 'ban'  },
    Heartbeat         = { enabled = true, action = 'kick', value = 120 },
    -- Entities
    BlacklistedEntity = { enabled = true, action = 'ban'  },
    EntityInjection   = { enabled = true, action = 'ban'  },
    VehicleSpam       = { enabled = true, action = 'ban',  value = 4 },
    PedSpam           = { enabled = true, action = 'ban',  value = 8 },
    ObjectSpam        = { enabled = true, action = 'ban',  value = 15 },
    EntitySpam        = { enabled = true, action = 'kick', value = 60 },
    ParticleSpam      = { enabled = true, action = 'kick', value = 40 },
    ParticleScale     = { enabled = true, action = 'ban',  value = 5 },     -- max particle size
    -- Explosions
    Explosion         = { enabled = true, action = 'kick', value = 10 },    -- explosions per 10s
    ExplosionScale    = { enabled = true, action = 'ban',  value = 1 },     -- max damage scale
    HiddenExplosion   = { enabled = true, action = 'log'  },                -- invisible + silent (blocked)
    BlacklistedExplosion = { enabled = true, action = 'ban' },
    FireSpam          = { enabled = true, action = 'kick', value = 15 },
    ProjectileSpam    = { enabled = true, action = 'kick', value = 40 },
}

Config.Strikes = {
    GodMode = 8, SpeedHack = 4, NoClip = 3, VehicleNoClip = 3, Invisible = 10, SuperJump = 2, FreeCam = 4,
    VehicleBoost = 2, HealthHack = 2, ArmorHack = 2, DamageModifier = 2, SuperPunch = 2, Injection = 2,
    VisionHack = 5, ShrinkPed = 2, InfiniteStamina = 1, RapidFire = 2, InfiniteAmmo = 1, ChangePed = 1,
}

Config.BlacklistedWeapons = {
    'WEAPON_RAILGUN', 'WEAPON_RAILGUNXM3', 'WEAPON_MINIGUN', 'WEAPON_RPG', 'WEAPON_HOMINGLAUNCHER',
    'WEAPON_GRENADELAUNCHER', 'WEAPON_EMPLAUNCHER', 'WEAPON_RAYMINIGUN', 'WEAPON_RAYPISTOL',
    'WEAPON_RAYCARBINE', 'WEAPON_FIREWORK', 'WEAPON_COMPACTLAUNCHER',
}

Config.BlacklistedEvents = {
    'HCheat:TempDisableDetection', 'adminmenu:allowall', 'mellotrainer:adminKick',
    'mellotrainer:adminTempBan', 'antilynx8:anticheat', 'lynx8:anticheat',
    'esx_mafia:pay', 'esx_gopostaljob:pay', 'esx_garbagejob:pay', 'esx_truckerjob:pay',
    'esx_pilot:success', 'esx_taxijob:success', 'esx_carthief:pay', 'esx_godirtyjob:pay',
    'esx_pizza:pay', 'esx_ranger:pay', 'esx_slotmachine:sv:2', 'esx_banksecurity:pay',
    'heroshield:honeypot',
}

Config.BlacklistedModels = {
    'cargoplane', 'jet', 'blimp', 'blimp2', 'blimp3', 'hydra', 'lazer', 'rhino', 'khanjali',
    'p_spinning_anus_s', 'prop_windmill_01', 'stt_prop_stunt_track_start',
    'prop_gold_cont_01', 'prop_fnclink_05crnr1', 'p_crahsed_heli_s', 'prop_juicestand',
    'prop_beach_fire', 'prop_container_05a', 'prop_cs_dildo_01', 'prop_ld_ferris_wheel',
}

-- Explosion types that are never allowed (ids, see docs.fivem.net explosion types)
-- 7 = plane, 29 = blimp, 33 = ship destroy, 37 = blimp2, 59 = orbital cannon, 82 = raygun
Config.BlacklistedExplosions = { 7, 29, 33, 37, 59, 82 }

-- Resources allowed to spawn entities even if not on the server (leave empty)
Config.EntityWhitelistScripts = {}
