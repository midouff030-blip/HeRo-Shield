Config = {}

-- Framework: 'auto', 'esx', 'qb', 'qbox' or 'standalone'
Config.Framework = 'auto'

-- Dashboard (get your key on the website)
Config.LicenseKey   = ''
Config.DashboardURL = ''   -- your website link, e.g. 'https://hero-shield.onrender.com'

-- Discord webhooks (you can also set them from the dashboard)
Config.Webhook    = ''   -- bans, kicks, detections
Config.LogWebhook = ''   -- server logs (empty = use Config.Webhook)

-- Admins (ACE, framework group or identifier)
Config.AdminAce         = 'heroshield.bypass'
Config.AdminGroups      = { 'god', 'superadmin', 'admin', 'mod' }
Config.AdminIdentifiers = {
    -- 'license:xxxxxxxx',
    -- 'discord:xxxxxxxx',
}
-- Admins are checked like everyone, EXCEPT for these (admin tools: txAdmin noclip,
-- godmode, spectate, /car, giveitem, revive...). Everything else bans admins too.
Config.AdminAllowed = {
    NoClip       = true,
    GodMode      = true,
    Invisible    = true,
    SpeedHack    = true,
    SuperJump    = true,
    Spectate     = true,
    FreeCam      = true,
    VehicleBoost = true,
    HealthArmor  = true,
    VisionHack   = true,
    Heartbeat    = true,
}

Config.BanMessage  = 'HeRo Shield | Banned: %s | Ban ID: %s'
Config.KickMessage = 'HeRo Shield | Kicked: %s'
Config.JoinGrace   = 60      -- seconds without client checks after joining
Config.Debug       = false

-- Server logs (sent to the dashboard + webhook)
Config.Logs = {
    Startup       = true,   -- anti-cheat started
    ResourceStart = true,   -- a resource started
    ResourceStop  = true,   -- a resource stopped
    Join          = true,   -- player joined
    Leave         = true,   -- player left
    Death         = true,   -- player died / was killed
    Revive        = true,   -- player was revived
    Weapon        = true,   -- player got a new weapon
    Explosion     = false,  -- every explosion (can spam)
    Admin         = true,   -- admin commands (ban, kick, unban)
}

-- Screenshots / proof / live view
Config.Screenshot = {
    Enabled        = true,
    Resource       = 'auto',  -- 'auto' (screencapture if started, else screenshot-basic), 'screencapture', 'screenshot-basic'
    -- Upload images here (empty = upload to your dashboard)
    -- imgbb example: 'https://api.imgbb.com/1/upload?key=YOUR_KEY'
    UploadUrl      = '',
    UploadField    = 'image', -- imgbb = 'image', Discord webhook = 'files[]'
    Quality        = 0.5,     -- 0.1 - 1.0
    ProofShots     = 3,       -- screenshots taken when a player is banned
    ProofGap       = 600,     -- ms between those screenshots
    Replay         = true,    -- keep the last minutes before a ban
    ReplayLength   = 240,     -- seconds kept (240 = 4 minutes)
    ReplayInterval = 15,      -- one screenshot every X seconds (lower = more FPS drops)
}

-- action: 'ban', 'kick' or 'log'
-- value: limit used by the detection
-- (all of this can be changed from the dashboard)
Config.Detections = {
    -- Client
    GodMode           = { enabled = true, action = 'ban'  },
    SpeedHack         = { enabled = true, action = 'kick', value = 12 },   -- max speed on foot (m/s)
    NoClip            = { enabled = true, action = 'ban'  },
    Invisible         = { enabled = true, action = 'kick' },
    SuperJump         = { enabled = true, action = 'kick', value = 4 },    -- max jump height (m)
    Spectate          = { enabled = true, action = 'ban'  },
    BlacklistedWeapon = { enabled = true, action = 'ban'  },
    DamageModifier    = { enabled = true, action = 'ban'  },               -- one shot / damage boost
    HealthArmor       = { enabled = true, action = 'ban'  },               -- health or armor above max
    VehicleBoost      = { enabled = true, action = 'kick' },               -- vehicle power boost
    FreeCam           = { enabled = true, action = 'kick', value = 120 },  -- max camera distance (m)
    VisionHack        = { enabled = true, action = 'log'  },               -- night / thermal vision
    Injection         = { enabled = true, action = 'ban'  },               -- unknown resource / fake token
    Heartbeat         = { enabled = true, action = 'kick', value = 120 },  -- seconds before kick
    -- Server (cheats cannot hide these)
    BlacklistedEvent  = { enabled = true, action = 'ban'  },
    EventSpam         = { enabled = true, action = 'kick', value = 40 },   -- events per second
    Explosion         = { enabled = true, action = 'kick', value = 10 },   -- explosions per 10s
    EntitySpam        = { enabled = true, action = 'kick', value = 60 },   -- entities per 10s
    BlacklistedEntity = { enabled = true, action = 'ban'  },
    EntityInjection   = { enabled = true, action = 'ban'  },               -- entity spawned by an injected menu
    FireSpam          = { enabled = true, action = 'kick', value = 15 },   -- fires per 10s
    ParticleSpam      = { enabled = true, action = 'kick', value = 40 },   -- particles per 10s
    ProjectileSpam    = { enabled = true, action = 'kick', value = 40 },   -- projectiles per 10s
    GiveWeaponOther   = { enabled = true, action = 'ban'  },               -- gives weapons to other players
    RemoveWeaponOther = { enabled = true, action = 'kick' },               -- removes weapons of other players
    ClearTasksOther   = { enabled = true, action = 'kick' },               -- kicks players out of cars / freezes them
    WeaponDamage      = { enabled = true, action = 'log',  value = 300 },  -- max damage per hit
}

-- Detections needed in a row before action (stops false bans)
Config.Strikes = {
    GodMode = 15, SpeedHack = 4, NoClip = 6, Invisible = 15, SuperJump = 2,
    FreeCam = 5, VehicleBoost = 3, HealthArmor = 3, DamageModifier = 2, Injection = 2, VisionHack = 5,
}

Config.BlacklistedWeapons = {
    'WEAPON_RAILGUN', 'WEAPON_RAILGUNXM3', 'WEAPON_MINIGUN', 'WEAPON_RPG', 'WEAPON_HOMINGLAUNCHER',
    'WEAPON_GRENADELAUNCHER', 'WEAPON_EMPLAUNCHER', 'WEAPON_RAYMINIGUN', 'WEAPON_RAYPISTOL',
    'WEAPON_RAYCARBINE', 'WEAPON_FIREWORK', 'WEAPON_COMPACTLAUNCHER',
}

-- Only events a normal player should NEVER trigger
Config.BlacklistedEvents = {
    'HCheat:TempDisableDetection', 'adminmenu:allowall', 'mellotrainer:adminKick',
    'mellotrainer:adminTempBan', 'antilynx8:anticheat', 'lynx8:anticheat',
    'esx_mafia:pay', 'esx_gopostaljob:pay', 'esx_garbagejob:pay', 'esx_truckerjob:pay',
    'esx_pilot:success', 'esx_taxijob:success', 'esx_carthief:pay', 'esx_godirtyjob:pay',
    'esx_pizza:pay', 'esx_ranger:pay', 'esx_slotmachine:sv:2', 'esx_banksecurity:pay',
    'heroshield:honeypot',
}

Config.BlacklistedModels = {
    'cargoplane', 'jet', 'blimp', 'blimp2', 'blimp3', 'hydra', 'lazer', 'rhino', 'khanjali',
    'p_spinning_anus_s', 'prop_windmill_01', 'stt_prop_stunt_track_start',
    'prop_gold_cont_01', 'prop_fnclink_05crnr1', 'p_crahsed_heli_s', 'prop_juicestand',
    'prop_beach_fire', 'prop_container_05a', 'prop_cs_dildo_01', 'prop_ld_ferris_wheel',
}
