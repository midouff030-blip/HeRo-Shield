Config = {}

-- Framework: 'auto', 'esx', 'qb', 'qbox' or 'standalone'
Config.Framework = 'auto'

-- Dashboard (get your key on the website)
Config.LicenseKey   = ''
Config.DashboardURL = 'https://heroshield.vercel.app/api'

-- Discord webhooks (you can also set them from the dashboard)
Config.Webhook    = ''   -- bans, kicks, detections
Config.LogWebhook = ''   -- server logs (empty = use Config.Webhook)

-- Admins are never banned or kicked
Config.AdminAce         = 'heroshield.bypass'
Config.AdminGroups      = { 'god', 'superadmin', 'admin', 'mod' }
Config.AdminIdentifiers = {
    -- 'license:xxxxxxxx',
    -- 'discord:xxxxxxxx',
}

Config.BanMessage = 'HeRo Shield | Banned: %s | Ban ID: %s'
Config.KickMessage = 'HeRo Shield | Kicked: %s'
Config.JoinGrace  = 60      -- seconds without checks after joining
Config.Debug      = false

-- Server logs (sent to the dashboard + webhook)
Config.Logs = {
    Startup       = true,   -- anti-cheat started
    ResourceStart = true,   -- a resource started
    ResourceStop  = true,   -- a resource stopped
    Join          = true,   -- player joined
    Leave         = true,   -- player left
    Death         = true,   -- player died / was killed
    Revive        = true,   -- player was revived
    Weapon        = true,   -- player got a new weapon
    Explosion     = false,  -- every explosion (can spam)
    Admin         = true,   -- admin commands (ban, kick, unban)
}

-- Proof (needs the screenshot-basic resource)
Config.Proof = {
    Screenshot     = true,   -- screenshot when a player is banned
    Replay         = true,   -- keep the last minutes of screenshots and upload them on ban
    ReplayLength   = 240,    -- seconds kept (240 = 4 minutes)
    ReplayInterval = 10,     -- one screenshot every X seconds
    Quality        = 0.3,    -- 0.1 - 1.0 (lower = smaller files)
}

-- action: 'ban', 'kick' or 'log'
-- value: limit used by the detection
-- (all of this can be changed from the dashboard)
Config.Detections = {
    GodMode           = { enabled = true, action = 'ban'  },
    SpeedHack         = { enabled = true, action = 'kick', value = 12 },   -- max speed on foot (m/s)
    NoClip            = { enabled = true, action = 'ban',  value = 60 },   -- max meters per second
    Invisible         = { enabled = true, action = 'ban'  },
    SuperJump         = { enabled = true, action = 'kick', value = 3 },    -- max jump height (m)
    Spectate          = { enabled = true, action = 'ban'  },
    BlacklistedWeapon = { enabled = true, action = 'ban'  },
    Injection         = { enabled = true, action = 'ban'  },
    Heartbeat         = { enabled = true, action = 'kick', value = 90 },   -- seconds before kick
    BlacklistedEvent  = { enabled = true, action = 'ban'  },
    EventSpam         = { enabled = true, action = 'kick', value = 40 },   -- events per second
    Explosion         = { enabled = true, action = 'ban',  value = 6 },    -- explosions per 10s
    EntitySpam        = { enabled = true, action = 'kick', value = 30 },   -- entities per 10s
    BlacklistedEntity = { enabled = true, action = 'ban'  },
    WeaponDamage      = { enabled = true, action = 'log',  value = 300 },  -- max damage per hit
}

-- Detections needed before action (less false bans)
Config.Strikes = { GodMode = 3, SpeedHack = 3, NoClip = 3, Invisible = 3, SuperJump = 2 }

Config.BlacklistedWeapons = {
    'WEAPON_RAILGUN', 'WEAPON_RAILGUNXM3', 'WEAPON_MINIGUN', 'WEAPON_RPG', 'WEAPON_HOMINGLAUNCHER',
    'WEAPON_GRENADELAUNCHER', 'WEAPON_EMPLAUNCHER', 'WEAPON_RAYMINIGUN', 'WEAPON_RAYPISTOL',
    'WEAPON_RAYCARBINE', 'WEAPON_FIREWORK', 'WEAPON_COMPACTLAUNCHER',
}

-- Only events a normal player should NEVER trigger
Config.BlacklistedEvents = {
    'HCheat:TempDisableDetection', 'adminmenu:allowall', 'mellotrainer:adminKick',
    'mellotrainer:adminTempBan', 'antilynx8:anticheat', 'lynx8:anticheat',
    'esx_mafia:pay', 'esx_gopostaljob:pay', 'esx_garbagejob:pay', 'esx_truckerjob:pay',
    'esx_pilot:success', 'esx_taxijob:success', 'esx_carthief:pay', 'esx_godirtyjob:pay',
    'esx_pizza:pay', 'esx_ranger:pay', 'esx_slotmachine:sv:2', 'esx_banksecurity:pay',
    'heroshield:honeypot',
}

Config.BlacklistedModels = {
    'cargoplane', 'jet', 'blimp', 'blimp2', 'blimp3', 'hydra', 'lazer', 'rhino', 'khanjali',
    'p_spinning_anus_s', 'prop_windmill_01', 'stt_prop_stunt_track_start',
    'prop_gold_cont_01', 'prop_fnclink_05crnr1', 'p_crahsed_heli_s', 'prop_juicestand',
}
