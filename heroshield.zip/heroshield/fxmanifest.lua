fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'HeRo Shield'
author 'HaMa'
description 'Free FiveM anti-cheat (ESX / QBCore / Qbox / Standalone)'
version '2.2.0'

shared_scripts {
    'shared/config.lua',
    'shared/defaults.lua',
    'shared/weapons.lua',
}

client_scripts {
    'client/main.lua',
    'client/detections.lua',
    'client/logs.lua',
    'client/proof.lua',
    'client/stream.lua',
    'client/advanced.lua',
}

server_scripts {
    'server/utils.lua',
    'server/framework.lua',
    'server/dashboard.lua',
    'server/logs.lua',
    'server/proof.lua',
    'server/bans.lua',
    'server/connect.lua',
    'server/main.lua',
    'server/detections.lua',
    'server/advanced.lua',
    'server/commands.lua',
    'server/remote.lua',
    'server/stream.lua',
    'server/startup.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/gameview.js',
    'html/stream.js',
}

dependency '/onesync'
