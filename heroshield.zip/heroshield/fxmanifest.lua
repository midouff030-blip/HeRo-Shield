fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'HeRo Shield'
author 'HaMa'
description 'Free FiveM anti-cheat (ESX / QBCore / Qbox / Standalone)'
version '1.2.0'

shared_script 'shared/config.lua'

client_scripts {
    'client/main.lua',
    'client/detections.lua',
}

server_scripts {
    'server/utils.lua',
    'server/framework.lua',
    'server/dashboard.lua',
    'server/bans.lua',
    'server/main.lua',
    'server/detections.lua',
    'server/commands.lua',
}

dependency '/onesync'
