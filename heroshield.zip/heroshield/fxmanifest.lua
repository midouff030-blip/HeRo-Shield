fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'HeRo Shield'
author 'HaMa'
description 'Free FiveM anti-cheat (ESX / QBCore / Qbox / Standalone)'
version '1.4.0'

shared_scripts {
    'shared/config.lua',
    'shared/weapons.lua',
}

client_scripts {
    'client/main.lua',
    'client/detections.lua',
    'client/logs.lua',
    'client/proof.lua',
}

server_scripts {
    'server/utils.lua',
    'server/framework.lua',
    'server/dashboard.lua',
    'server/logs.lua',
    'server/proof.lua',
    'server/bans.lua',
    'server/main.lua',
    'server/detections.lua',
    'server/commands.lua',
    'server/remote.lua',
    'server/startup.lua',
}

dependency '/onesync'
