-- Live stream to the dashboard (Multi Stream)
-- ws:// / wss:// url  -> smooth video from the game view (NUI, no extra resource)
-- http(s) url         -> fallback with screenshot-basic (old website version)
local httpUntil = 0

local function httpFallback(url)
    local running = httpUntil > GetGameTimer()
    httpUntil = GetGameTimer() + 60000
    if running or GetResourceState('screenshot-basic') ~= 'started' then return end
    CreateThread(function()
        while GetGameTimer() < httpUntil do
            local done = false
            exports['screenshot-basic']:requestScreenshotUpload(url, 'files[]',
                { encoding = 'jpg', quality = Config.Screenshot.StreamQuality or 0.35 },
                function(res)
                    done = true
                    if res == 'stop' then httpUntil = 0 end
                end)
            local t = GetGameTimer() + 3000
            while not done and GetGameTimer() < t do Wait(20) end
            Wait(150)
        end
    end)
end

RegisterNetEvent('heroshield:stream', function(url)
    if type(url) ~= 'string' then return end
    if url:sub(1, 6) == 'wss://' or url:sub(1, 5) == 'ws://' then
        SendNUIMessage({
            action   = 'hs:stream:start',
            url      = url,
            fps      = Config.Stream.Fps,
            width    = Config.Stream.Width,
            quality  = Config.Stream.Quality,
            duration = 60,
        })
    elseif url:sub(1, 4) == 'http' then
        httpFallback(url)
    end
end)

RegisterNetEvent('heroshield:streamstop', function()
    httpUntil = 0
    SendNUIMessage({ action = 'hs:stream:stop' })
end)
