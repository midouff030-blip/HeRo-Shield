-- Screenshots (screenshot-basic) for proof, replay and live view.
-- If the server uses "screencapture", screenshots are taken from the server side instead.
local frames = {}
local busy = false

local function available()
    return GetResourceState('screenshot-basic') == 'started'
end

local function take(cb)
    exports['screenshot-basic']:requestScreenshot({ encoding = 'jpg', quality = Config.Screenshot.Quality }, cb)
end

local function send(kind, id, index, data, bps)
    if HSC.token then
        TriggerLatentServerEvent('heroshield:upload', bps or 500000, HSC.token, kind, id or '', index or 0, data or '')
    end
end

-- Replay buffer: the last ReplayLength seconds
CreateThread(function()
    while true do
        local interval = math.max(5, tonumber(Config.Screenshot.ReplayInterval) or 15)
        Wait(interval * 1000)
        if Config.Screenshot.Enabled and Config.Screenshot.Replay and HSC.active() and available() and not busy then
            busy = true
            take(function(data)
                busy = false
                frames[#frames + 1] = data
                local max = math.floor((tonumber(Config.Screenshot.ReplayLength) or 240) / interval)
                while #frames > max do table.remove(frames, 1) end
            end)
        end
    end
end)

-- One screenshot asked by the server (proof / live view)
RegisterNetEvent('heroshield:capture', function(id)
    if not available() then return send('capture', id, 0, '') end
    take(function(data) send('capture', id, 0, data, 1000000) end)
end)

-- Send the replay buffer (on ban)
RegisterNetEvent('heroshield:replay', function(banId)
    local list = frames
    frames = {}
    for i, frame in ipairs(list) do send('replay', banId, i, frame) end
    send('replaydone', banId)
end)
