-- Screenshots for proof, replay and live view (needs screenshot-basic)
local frames = {}
local busy = false

local function available()
    return GetResourceState('screenshot-basic') == 'started'
end

local function take(cb)
    exports['screenshot-basic']:requestScreenshot({ encoding = 'jpg', quality = Config.Proof.Quality }, cb)
end

local function upload(kind, banId, index, data, bps)
    TriggerLatentServerEvent('heroshield:upload', bps or 500000, HSC.token, kind, banId or '', index or 0, data or '')
end

-- Replay buffer: keeps the last ReplayLength seconds
CreateThread(function()
    while true do
        local interval = math.max(5, tonumber(Config.Proof.ReplayInterval) or 10)
        Wait(interval * 1000)
        if Config.Proof.Replay and HSC.active() and available() and not busy then
            take(function(data)
                frames[#frames + 1] = data
                local max = math.floor((tonumber(Config.Proof.ReplayLength) or 240) / interval)
                while #frames > max do table.remove(frames, 1) end
            end)
        end
    end
end)

-- Ban: screenshot now + replay
RegisterNetEvent('heroshield:proof', function(banId)
    if not HSC.token then return end
    if not available() then return upload('done', banId) end
    busy = true
    local replay = frames
    frames = {}
    take(function(data)
        upload('ban', banId, 0, data)
        if Config.Proof.Replay then
            for i, frame in ipairs(replay) do upload('replay', banId, i, frame) end
        end
        upload('done', banId)
        busy = false
    end)
end)

-- Live view from the dashboard
RegisterNetEvent('heroshield:live', function()
    if not HSC.token or busy or not available() then return end
    take(function(data) upload('live', '', 0, data, 1000000) end)
end)
