-- Advanced client checks: Lua tamper, menus, resource stop, devtools, semi godmode,
-- ghost mode, vehicle speed modifier, silent aim reports (victim side = cannot be bypassed by the cheater)
local function check(name) return HSC.det(name) and HSC.active(name) end

HSC.ticks = 0   -- grows while the checks run (sent with the heartbeat)

-- ===== Lua tamper: natives / events replaced by an injected menu =====
local watched = {
    'GetEntityHealth', 'SetEntityHealth', 'GetEntityCoords', 'SetEntityCoords', 'GetEntitySpeed',
    'GetPlayerInvincible', 'IsEntityVisible', 'GetSelectedPedWeapon', 'NetworkIsInSpectatorMode',
    'TriggerServerEvent', 'TriggerEvent', 'PlayerPedId', 'GetPedArmour', 'GetEntityProofs',
}
local original = {}
for _, n in ipairs(watched) do original[n] = _G[n] end

local function nativeSource(fn)
    local ok, info = pcall(debug.getinfo, fn, 'S')
    if not ok or type(info) ~= 'table' then return nil end
    return info.source or ''
end
local trusted = {}
for _, n in ipairs(watched) do trusted[n] = nativeSource(original[n]) end

-- globals created by well known Lua menus
local MENU_GLOBALS = {
    'LynxEvo', 'Lynx8', 'LynxSeven', 'MainMenu', 'Dopamine', 'RedEngine', 'TiagoMenu', 'SkidMenu', 'KoGuSzEk',
    'HamMafia', 'FantaMenu', 'Brutan', 'JokerMenu', 'InSec', 'oTable', 'Biznes', 'Crusader', 'Plane', 'nukeserver',
    'AlphaVeta', 'b00mMenu', 'FendinX', 'Absolute', 'WarMenu', 'Cience', 'MaestroMenu', 'Hoax', 'LuxUI', 'Ham',
}

CreateThread(function()
    while true do
        Wait(5000)
        if HSC.ready then
            if check('LuaTamper') then
                for _, n in ipairs(watched) do
                    local now = _G[n]
                    if now ~= original[n] then
                        HSC.flag('LuaTamper', n .. ' was replaced')
                        break
                    end
                    local src = nativeSource(now)
                    if trusted[n] and src and src ~= trusted[n] then
                        HSC.flag('LuaTamper', n .. ' hooked from ' .. src:sub(1, 60))
                        break
                    end
                end
            end
            if check('LuaMenu') then
                for _, g in ipairs(MENU_GLOBALS) do
                    if rawget(_G, g) ~= nil then
                        HSC.flag('LuaMenu', 'menu global: ' .. g)
                        break
                    end
                end
            end
        end
    end
end)

-- ===== Resource stopped on the player PC (server checks it is still running) =====
AddEventHandler('onClientResourceStop', function(res)
    if HSC.token then TriggerServerEvent('heroshield:resstop', HSC.token, res) end
end)

-- ===== NUI devtools opened (message from html/stream.js) =====
RegisterNUICallback('devtools', function(_, cb)
    if HSC.ready and check('DevTools') then HSC.flag('DevTools', 'NUI devtools opened') end
    cb('ok')
end)

-- ===== Semi godmode / ghost mode / vehicle speed modifier (every second) =====
local lastHealth = 0
CreateThread(function()
    while true do
        Wait(1000)
        HSC.ticks = HSC.ticks + 1
        local ped = PlayerPedId()
        lastHealth = GetEntityHealth(ped)

        if HSC.ready then
            if check('GhostMode') then
                if GetEntityAlpha(ped) < 60 and IsEntityVisible(ped) and not IsEntityDead(ped) and not IsCutsceneActive() then
                    HSC.flag('GhostMode', ('alpha %d'):format(GetEntityAlpha(ped)))
                else HSC.decay('GhostMode') end
            end
            if check('VehicleSpeedModifier') then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                    local mod = GetVehicleTopSpeedModifier(veh)
                    if mod and mod > 1.05 then
                        HSC.flag('VehicleSpeedModifier', ('top speed x%.2f'):format(mod))
                    else HSC.decay('VehicleSpeedModifier') end
                end
            end
        end
    end
end)

-- ===== Damage events: semi godmode (me) + silent aim (attacker) =====
local MELEE = { [GetHashKey('WEAPON_UNARMED')] = true }
AddEventHandler('gameEventTriggered', function(name, args)
    if name ~= 'CEventNetworkEntityDamage' or not HSC.ready or not HSC.token then return end
    local victim, attacker, fatal, weapon = args[1], args[2], args[6] == 1, args[7]
    local ped = PlayerPedId()
    if victim ~= ped or attacker == ped or not attacker or attacker == 0 then return end
    if not IsEntityAPed(attacker) or not IsPedAPlayer(attacker) then return end

    -- semi godmode: hit by a player, health instantly back
    if check('SemiGodMode') and not fatal then
        local before = lastHealth
        SetTimeout(300, function()
            local now = GetEntityHealth(ped)
            if before > 0 and now >= before and now >= GetEntityMaxHealth(ped) - 1 then
                HSC.flag('SemiGodMode', 'health restored after a hit')
            end
        end)
    end

    -- silent aim / magic bullet: the shooter could not see me
    if not MELEE[weapon] and not IsPedInAnyVehicle(attacker, false) then
        local dist = #(GetEntityCoords(attacker) - GetEntityCoords(ped))
        if dist > 8.0 and not HasEntityClearLosToEntity(attacker, ped, 17) then
            local id = GetPlayerServerId(NetworkGetPlayerIndexFromPed(attacker))
            if id and id > 0 then TriggerServerEvent('heroshield:report', HSC.token, 'silentaim', id, math.floor(dist)) end
        end
    end
end)
