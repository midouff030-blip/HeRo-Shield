-- Death, revive and new weapons (sent to the server logs)
local weaponNames = {}
for _, w in ipairs(Weapons) do weaponNames[GetHashKey(w)] = w end

local function send(kind, data)
    if HSC.token then TriggerServerEvent('heroshield:log', HSC.token, kind, data) end
end

-- Death / revive
CreateThread(function()
    local wasDead = false
    while true do
        Wait(500)
        if HSC.token then
            local ped = PlayerPedId()
            local dead = IsEntityDead(ped) or IsPedFatallyInjured(ped)
            if dead and not wasDead then
                local killerPed = GetPedSourceOfDeath(ped)
                local killer = 0
                if killerPed ~= 0 and killerPed ~= ped and IsPedAPlayer(killerPed) then
                    killer = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killerPed))
                end
                local cause = GetPedCauseOfDeath(ped)
                send('death', { killer = killer, weapon = weaponNames[cause] or tostring(cause) })
            elseif not dead and wasDead then
                send('revive', {})
            end
            wasDead = dead
        end
    end
end)

-- New weapons
CreateThread(function()
    local owned
    while true do
        Wait(3000)
        if HSC.token then
            local ped = PlayerPedId()
            local now = {}
            for hash, name in pairs(weaponNames) do
                if HasPedGotWeapon(ped, hash, false) then now[hash] = name end
            end
            if owned then
                for hash, name in pairs(now) do
                    if not owned[hash] then send('weapon', { weapon = name }) end
                end
            end
            owned = now
        end
    end
end)
