HSC = {
    isAdmin = false,
    ready   = false,
    token   = nil,
    strikes = {},
}

function HSC.det(name)
    local d = Config.Detections[name]
    return d and d.enabled
end

function HSC.value(name)
    return tonumber(Config.Detections[name].value) or 0
end

-- admins skip only the detections in Config.AdminAllowed
function HSC.active(name)
    if not HSC.ready then return false end
    if not HSC.isAdmin or not name then return true end
    return Config.AdminAllowed[name] ~= true
end

function HSC.flag(name, info)
    if not HSC.active(name) or not HSC.token then return end
    HSC.strikes[name] = (HSC.strikes[name] or 0) + 1
    if HSC.strikes[name] >= (Config.Strikes[name] or 1) then
        HSC.strikes[name] = 0
        TriggerServerEvent('heroshield:detect', HSC.token, name, info or '')
    end
end

-- clean check = strikes start again from 0 (detections must be in a row)
function HSC.decay(name)
    HSC.strikes[name] = 0
end

RegisterNetEvent('heroshield:init', function(token, admin, detections)
    HSC.isAdmin = admin
    if type(detections) == 'table' then Config.Detections = detections end
    if HSC.token then return end
    HSC.token = token
    SetTimeout(Config.JoinGrace * 1000, function() HSC.ready = true end)
end)

RegisterNetEvent('heroshield:config', function(detections, admin)
    if type(detections) == 'table' then Config.Detections = detections end
    if admin ~= nil then HSC.isAdmin = admin end
end)

CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(500) end
    TriggerServerEvent('heroshield:ready')
end)

CreateThread(function()
    while true do
        Wait(20000)
        if HSC.token then TriggerServerEvent('heroshield:hb', HSC.token) end
    end
end)

RegisterNetEvent('heroshield:shot', function(url)
    if GetResourceState('screenshot-basic') ~= 'started' then return end
    exports['screenshot-basic']:requestScreenshotUpload(url, 'files[]', function() end)
end)
