HSC = {
    txMode  = 'none',   -- txAdmin player mode: 'none', 'noclip', 'godmode', 'superjump'
    isAdmin = false,
    ready   = false,
    token   = nil,
    strikes = {},
}

function HSC.det(name)
    local d = Config.Detections[name]
    return d and d.enabled
end

function HSC.value(name)
    return tonumber(Config.Detections[name].value) or 0
end

-- admins skip only the detections in Config.AdminAllowed
function HSC.active(name)
    if not HSC.ready then return false end
    if not HSC.isAdmin or not name then return true end
    if not Config.AdminAllowed[name] then return true end
    -- noclip/godmode... allowed only while txAdmin mode is on
    if Config.AdminTxAdminOnly[name] and Config.Settings.TxAdminIntegration then return HSC.txMode == 'none' end
    return false
end

-- txAdmin menu tells the client when noclip / godmode / superjump is turned on or off
RegisterNetEvent('txcl:setPlayerMode', function(mode)
    HSC.txMode = type(mode) == 'string' and mode or 'none'
    HSC.strikes = {}
end)

function HSC.flag(name, info)
    if not HSC.active(name) or not HSC.token then return end
    HSC.strikes[name] = (HSC.strikes[name] or 0) + 1
    if HSC.strikes[name] >= (Config.Strikes[name] or 1) then
        HSC.strikes[name] = 0
        TriggerServerEvent('heroshield:detect', HSC.token, name, info or '')
    end
end

-- clean check = strikes start again from 0 (detections must be in a row)
function HSC.decay(name)
    HSC.strikes[name] = 0
end

RegisterNetEvent('heroshield:init', function(token, admin, detections, grace)
    HSC.isAdmin = admin
    if type(detections) == 'table' then Config.Detections = detections end
    if HSC.token then return end
    HSC.token = token
    SetTimeout((tonumber(grace) or Config.JoinGrace) * 1000, function() HSC.ready = true end)
end)

HSC.listeners = {}
RegisterNetEvent('heroshield:config', function(detections, admin, extra)
    if type(detections) == 'table' then Config.Detections = detections end
    if admin ~= nil then HSC.isAdmin = admin end
    if type(extra) == 'table' then
        if type(extra.settings) == 'table' then Config.Settings = extra.settings end
        if type(extra.weapons) == 'table' then Config.BlacklistedWeapons = extra.weapons end
        for _, fn in ipairs(HSC.listeners) do pcall(fn) end
    end
end)

CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(500) end
    TriggerServerEvent('heroshield:ready')
end)

CreateThread(function()
    while true do
        Wait(20000)
        if HSC.token then TriggerServerEvent('heroshield:hb', HSC.token, HSC.ticks or 0) end
    end
end)

RegisterNetEvent('heroshield:shot', function(url)
    if GetResourceState('screenshot-basic') ~= 'started' then return end
    exports['screenshot-basic']:requestScreenshotUpload(url, 'files[]', function() end)
end)
