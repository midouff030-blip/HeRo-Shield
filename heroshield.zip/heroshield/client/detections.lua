-- Client checks. Every check skips normal game/framework situations to avoid false bans.
local badWeapons = {}
for _, w in ipairs(Config.BlacklistedWeapons) do badWeapons[GetHashKey(w)] = w end

-- Situations where movement/visibility checks must not run
local function busy(ped)
    return IsPedInAnyVehicle(ped, false) or IsPedFalling(ped) or IsPedRagdoll(ped)
        or IsPedInParachuteFreeFall(ped) or GetPedParachuteState(ped) > 0
        or IsEntityAttached(ped) or IsPlayerSwitchInProgress() or IsEntityDead(ped)
        or IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped) or IsPedClimbing(ped)
        or IsCutsceneActive() or IsScreenFadedOut() or IsScreenFadingOut() or IsScreenFadingIn()
        or IsEntityPositionFrozen(ped) or IsPedGettingIntoAVehicle(ped)
end

local function check(name)
    return HSC.det(name) and HSC.active(name)
end

-- Main checks (every second)
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local ply = PlayerId()

        if HSC.ready then
            local isBusy = busy(ped)

            -- GodMode: invincible for 15s in a row, while visible and not frozen
            if check('GodMode') then
                if not isBusy and IsEntityVisible(ped)
                    and (GetPlayerInvincible(ply) or GetPlayerInvincible_2(ply) or not GetEntityCanBeDamaged(ped)) then
                    HSC.flag('GodMode', 'invincible')
                else HSC.decay('GodMode') end
            end

            -- SpeedHack on foot
            if check('SpeedHack') then
                local speed = GetEntitySpeed(ped)
                if not isBusy and speed > HSC.value('SpeedHack') then
                    HSC.flag('SpeedHack', ('%.1f m/s'):format(speed))
                else HSC.decay('SpeedHack') end
            end

            -- NoClip: no collision + floating in the air + moving, several seconds in a row
            if check('NoClip') then
                local noCollision = GetEntityCollisionDisabled(ped)
                local height = GetEntityHeightAboveGround(ped)
                local vz = GetEntityVelocity(ped).z
                local floating = height > 3.0 and math.abs(vz) < 1.0 and GetEntitySpeed(ped) > 2.0
                if not isBusy and (noCollision and GetEntitySpeed(ped) > 1.0 or floating) then
                    HSC.flag('NoClip', noCollision and 'no collision' or ('floating %.0fm'):format(height))
                else HSC.decay('NoClip') end
            end

            -- Invisible for 15s in a row (frameworks hide players while frozen/loading)
            if check('Invisible') then
                if not isBusy and not IsEntityVisible(ped) and NetworkIsPlayerActive(ply) then
                    HSC.flag('Invisible', 'invisible ped')
                else HSC.decay('Invisible') end
            end

            -- Spectate
            if check('Spectate') and NetworkIsInSpectatorMode() then
                HSC.flag('Spectate', 'spectator mode')
            end

            -- Blacklisted weapon in hand
            if check('BlacklistedWeapon') then
                local w = GetSelectedPedWeapon(ped)
                if badWeapons[w] then
                    RemoveWeaponFromPed(ped, w)
                    HSC.flag('BlacklistedWeapon', badWeapons[w])
                end
            end

            -- Damage boost / one shot
            if check('DamageModifier') then
                local weapon = GetPlayerWeaponDamageModifier(ply)
                local melee = GetPlayerMeleeWeaponDamageModifier(ply)
                local defense = GetPlayerWeaponDefenseModifier(ply)
                if weapon > 1.01 or melee > 1.01 or (defense > 0 and defense < 0.5) then
                    HSC.flag('DamageModifier', ('weapon x%.2f melee x%.2f defense x%.2f'):format(weapon, melee, defense))
                else HSC.decay('DamageModifier') end
            end

            -- Health / armor above max
            if check('HealthArmor') then
                local health, maxHealth = GetEntityHealth(ped), GetEntityMaxHealth(ped)
                local armor = GetPedArmour(ped)
                if (maxHealth > 0 and health > maxHealth + 5) or armor > 100 then
                    HSC.flag('HealthArmor', ('health %d/%d armor %d'):format(health, maxHealth, armor))
                else HSC.decay('HealthArmor') end
            end

            -- Vehicle power boost
            if check('VehicleBoost') then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                    local power = GetVehicleCheatPowerIncrease(veh)
                    if power > 1.01 then
                        HSC.flag('VehicleBoost', ('power x%.2f'):format(power))
                    else HSC.decay('VehicleBoost') end
                else HSC.decay('VehicleBoost') end
            end

            -- FreeCam: game camera far away from the player without any script camera
            if check('FreeCam') then
                local dist = #(GetFinalRenderedCamCoord() - GetEntityCoords(ped))
                if GetRenderingCam() == -1 and not IsCutsceneActive() and not IsPlayerSwitchInProgress()
                    and not NetworkIsInSpectatorMode() and dist > HSC.value('FreeCam') then
                    HSC.flag('FreeCam', ('camera %.0fm away'):format(dist))
                else HSC.decay('FreeCam') end
            end

            -- Night / thermal vision outside of an aircraft
            if check('VisionHack') then
                if (GetUsingnightvision() or GetUsingseethrough()) and not IsPedInAnyHeli(ped) and not IsPedInAnyPlane(ped) then
                    HSC.flag('VisionHack', GetUsingseethrough() and 'thermal vision' or 'night vision')
                else HSC.decay('VisionHack') end
            end
        end
    end
end)

-- Super jump
CreateThread(function()
    while true do
        Wait(300)
        if HSC.ready and check('SuperJump') then
            local ped = PlayerPedId()
            if IsPedJumping(ped) and not IsPedInAnyVehicle(ped, false) and not IsPedRagdoll(ped) then
                local startZ = GetEntityCoords(ped).z
                local peak = startZ
                while IsPedJumping(ped) do
                    Wait(50)
                    local z = GetEntityCoords(ped).z
                    if z > peak then peak = z end
                end
                local height = peak - startZ
                if height > HSC.value('SuperJump') then
                    HSC.flag('SuperJump', ('%.1f m'):format(height))
                else HSC.decay('SuperJump') end
            end
        end
    end
end)

-- Unknown resources (injected menus)
CreateThread(function()
    while true do
        Wait(60000)
        if HSC.token and check('Injection') then
            local list = {}
            for i = 0, GetNumResources() - 1 do
                local r = GetResourceByFindIndex(i)
                if r and r:sub(1, 1) ~= '_' and GetResourceState(r) == 'started' then list[#list + 1] = r end
            end
            TriggerServerEvent('heroshield:resources', HSC.token, list)
        end
    end
end)
