-- Client checks. Every check skips normal game/framework situations to avoid false bans.
local badWeapons = {}
local function rebuildWeapons()
    badWeapons = {}
    for _, w in ipairs(Config.BlacklistedWeapons) do badWeapons[GetHashKey(w)] = w end
end
rebuildWeapons()
HSC.listeners[#HSC.listeners + 1] = rebuildWeapons

-- Situations where movement/visibility checks must not run
local function busy(ped)
    return IsPedInAnyVehicle(ped, false) or IsPedFalling(ped) or IsPedRagdoll(ped)
        or IsPedInParachuteFreeFall(ped) or GetPedParachuteState(ped) > 0
        or IsEntityAttached(ped) or IsPlayerSwitchInProgress() or IsEntityDead(ped)
        or IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped) or IsPedClimbing(ped)
        or IsCutsceneActive() or IsScreenFadedOut() or IsScreenFadingOut() or IsScreenFadingIn()
        or IsEntityPositionFrozen(ped) or IsPedGettingIntoAVehicle(ped)
end

local function check(name)
    return HSC.det(name) and HSC.active(name)
end

-- Main checks (every second)
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local ply = PlayerId()

        if HSC.ready then
            local isBusy = busy(ped)

            -- GodMode: invincible / all damage proofs, several seconds in a row
            if check('GodMode') then
                local _, bullet, fire, explosion, _, melee = GetEntityProofs(ped)
                local proofs = bullet == 1 or bullet == true
                proofs = proofs and (fire == 1 or fire == true) and (explosion == 1 or explosion == true) and (melee == 1 or melee == true)
                if not isBusy and IsEntityVisible(ped)
                    and (GetPlayerInvincible(ply) or GetPlayerInvincible_2(ply) or not GetEntityCanBeDamaged(ped) or proofs) then
                    HSC.flag('GodMode', proofs and 'all damage proofs' or 'invincible')
                else HSC.decay('GodMode') end
            end

            -- Invisible for 15s in a row (frameworks hide players while frozen/loading)
            if check('Invisible') then
                if not isBusy and not IsEntityVisible(ped) and NetworkIsPlayerActive(ply) then
                    HSC.flag('Invisible', 'invisible ped')
                else HSC.decay('Invisible') end
            end

            -- Spectate
            if check('Spectate') and NetworkIsInSpectatorMode() then
                HSC.flag('Spectate', 'spectator mode')
            end

            -- Blacklisted weapon in hand
            if check('BlacklistedWeapon') then
                local w = GetSelectedPedWeapon(ped)
                if badWeapons[w] then
                    RemoveWeaponFromPed(ped, w)
                    HSC.flag('BlacklistedWeapon', badWeapons[w])
                end
            end

            -- Damage boost / one shot
            if check('DamageModifier') then
                local weapon = GetPlayerWeaponDamageModifier(ply)
                local defense = GetPlayerWeaponDefenseModifier(ply)
                if weapon > 1.01 or (defense > 0 and defense < 0.5) then
                    HSC.flag('DamageModifier', ('weapon x%.2f defense x%.2f'):format(weapon, defense))
                else HSC.decay('DamageModifier') end
            end

            -- Super punch (melee boost)
            if check('SuperPunch') then
                local melee = GetPlayerMeleeWeaponDamageModifier(ply)
                if melee > 1.01 then
                    HSC.flag('SuperPunch', ('melee x%.2f'):format(melee))
                else HSC.decay('SuperPunch') end
            end

            -- Health / armor above max
            local health, maxHealth = GetEntityHealth(ped), GetEntityMaxHealth(ped)
            if check('HealthHack') then
                if maxHealth > 0 and (health > maxHealth + 5 or maxHealth > 400) then
                    HSC.flag('HealthHack', ('health %d/%d'):format(health, maxHealth))
                else HSC.decay('HealthHack') end
            end
            if check('ArmorHack') then
                local armor = GetPedArmour(ped)
                if armor > 100 then
                    HSC.flag('ArmorHack', ('armor %d'):format(armor))
                else HSC.decay('ArmorHack') end
            end

            -- Shrink ped
            if check('ShrinkPed') then
                if GetPedConfigFlag(ped, 223, true) then
                    HSC.flag('ShrinkPed', 'shrink flag')
                else HSC.decay('ShrinkPed') end
            end

            -- Animal / weird ped model (change ped menus)
            if check('ChangePed') then
                local ptype = GetPedType(ped)
                if ptype == 28 and not IsPedInAnyVehicle(ped, false) then
                    HSC.flag('ChangePed', ('animal ped model %s'):format(GetEntityModel(ped)))
                else HSC.decay('ChangePed') end
            end

            -- Infinite stamina: sprinting 60s without losing stamina
            if check('InfiniteStamina') then
                HSC.sprint = HSC.sprint or 0
                if IsPedSprinting(ped) and not IsPedInAnyVehicle(ped, false) and GetPlayerSprintStaminaRemaining(ply) <= 0.0 then
                    HSC.sprint = HSC.sprint + 1
                    if HSC.sprint >= 60 then
                        HSC.sprint = 0
                        HSC.flag('InfiniteStamina', 'sprinted 60s with full stamina')
                    end
                elseif not IsPedSprinting(ped) then
                    HSC.sprint = 0
                end
            end

            -- Vehicle power boost
            if check('VehicleBoost') then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                    local power = GetVehicleCheatPowerIncrease(veh)
                    if power > 1.01 then
                        HSC.flag('VehicleBoost', ('power x%.2f'):format(power))
                    else HSC.decay('VehicleBoost') end
                else HSC.decay('VehicleBoost') end
            end

            -- FreeCam: game camera far away from the player without any script camera
            if check('FreeCam') then
                local dist = #(GetFinalRenderedCamCoord() - GetEntityCoords(ped))
                if GetRenderingCam() == -1 and not IsCutsceneActive() and not IsPlayerSwitchInProgress()
                    and not NetworkIsInSpectatorMode() and dist > HSC.value('FreeCam') then
                    HSC.flag('FreeCam', ('camera %.0fm away'):format(dist))
                else HSC.decay('FreeCam') end
            end

            -- Night / thermal vision outside of an aircraft
            if check('VisionHack') then
                if (GetUsingnightvision() or GetUsingseethrough()) and not IsPedInAnyHeli(ped) and not IsPedInAnyPlane(ped) then
                    HSC.flag('VisionHack', GetUsingseethrough() and 'thermal vision' or 'night vision')
                else HSC.decay('VisionHack') end
            end
        end
    end
end)

-- Movement checks every 0.5s: NoClip + SpeedHack
-- Noclip menus freeze the ped / disable collision and move it with coordinates:
-- the ped moves but its real speed stays ~0. A teleport is one big jump, noclip moves again and again.
local function moveBusy(ped)
    return IsPedInAnyVehicle(ped, false) or IsPedInParachuteFreeFall(ped) or GetPedParachuteState(ped) > 0
        or IsPedRagdoll(ped) or IsEntityAttached(ped) or IsEntityDead(ped) or IsPedSwimming(ped)
        or IsPedSwimmingUnderWater(ped) or IsPedClimbing(ped) or IsCutsceneActive() or IsPlayerSwitchInProgress()
        or IsScreenFadedOut() or IsScreenFadingOut() or IsScreenFadingIn() or IsPedGettingIntoAVehicle(ped)
        or NetworkIsInSpectatorMode()
end

CreateThread(function()
    local last
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)

        -- Teleport to waypoint: one big jump that lands on the map waypoint
        if HSC.ready and last and check('TeleportWaypoint') and IsWaypointActive() then
            local jump = #(pos - last)
            if jump > 100.0 and not IsPedInAnyVehicle(ped, false) then
                local wp = GetBlipInfoIdCoord(GetFirstBlipInfoId(8))
                if #(vector2(pos.x, pos.y) - vector2(wp.x, wp.y)) < 10.0 then
                    HSC.flag('TeleportWaypoint', ('teleported %.0fm to the waypoint'):format(jump))
                end
            end
        end

        -- Vehicle noclip: driver's car moves with no collision / frozen / without real speed
        if HSC.ready and check('VehicleNoClip') then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local vpos = GetEntityCoords(veh)
                local moved = HSC.lastVeh and #(vpos - HSC.lastVeh) or 0
                local noCol = GetEntityCollisionDisabled(veh) or IsEntityPositionFrozen(veh)
                local air = not IsVehicleOnAllWheels(veh) and GetEntityHeightAboveGround(veh) > 3.0
                    and math.abs(GetEntityVelocity(veh).z) < 1.0 and not IsThisModelAHeli(GetEntityModel(veh))
                    and not IsThisModelAPlane(GetEntityModel(veh))
                if moved > 2.0 and moved < 300.0 and (noCol or (air and GetEntitySpeed(veh) < 1.0)) then
                    HSC.flag('VehicleNoClip', ('car moved %.1fm in 0.5s (speed %.1f)'):format(moved, GetEntitySpeed(veh)))
                else HSC.decay('VehicleNoClip') end
                HSC.lastVeh = vpos
            else
                HSC.lastVeh = nil
            end
        end

        if HSC.ready and last then
            local busy = moveBusy(ped)
            local moved = #(pos - last)
            local speed = GetEntitySpeed(ped)

            if check('NoClip') then
                local frozen = IsEntityPositionFrozen(ped)
                local noCollision = GetEntityCollisionDisabled(ped)
                local floating = GetEntityHeightAboveGround(ped) > 2.5 and not IsPedFalling(ped) and not IsPedJumping(ped)
                    and math.abs(GetEntityVelocity(ped).z) < 1.0
                if not busy and moved > 1.0 and moved < 300.0 and (speed < 0.5 or frozen or noCollision or floating) then
                    HSC.flag('NoClip', ('moved %.1fm in 0.5s (speed %.1f%s%s%s)'):format(moved, speed,
                        frozen and ', frozen' or '', noCollision and ', no collision' or '', floating and ', floating' or ''))
                else HSC.decay('NoClip') end
            end

            if check('SpeedHack') then
                if not busy and not IsPedFalling(ped) and speed > HSC.value('SpeedHack') then
                    HSC.flag('SpeedHack', ('%.1f m/s'):format(speed))
                else HSC.decay('SpeedHack') end
            end
        end
        last = pos
    end
end)

-- Rapid fire + infinite ammo (checked every frame only while shooting)
CreateThread(function()
    local shots, window, sameAmmo, lastAmmo = 0, GetGameTimer(), 0, nil
    while true do
        local ped = PlayerPedId()
        if HSC.ready and IsPedShooting(ped) then
            local now = GetGameTimer()
            if now - window > 1000 then
                if check('RapidFire') and shots > HSC.value('RapidFire') then
                    HSC.flag('RapidFire', ('%d shots in 1s'):format(shots))
                end
                shots, window = 0, now
            end
            shots = shots + 1

            if check('InfiniteAmmo') then
                local weapon = GetSelectedPedWeapon(ped)
                local _, clip = GetAmmoInClip(ped, weapon)
                if lastAmmo and clip >= lastAmmo and GetWeaponClipSize(weapon) > 1 then
                    sameAmmo = sameAmmo + 1
                    if sameAmmo >= 40 then
                        sameAmmo = 0
                        HSC.flag('InfiniteAmmo', ('shot 40 times, clip stays %d'):format(clip))
                    end
                elseif lastAmmo and clip < lastAmmo then
                    sameAmmo = 0
                end
                lastAmmo = clip
            end
            Wait(0)
        else
            lastAmmo = nil
            Wait(150)
        end
    end
end)

-- Super jump
CreateThread(function()
    while true do
        Wait(300)
        if HSC.ready and check('SuperJump') then
            local ped = PlayerPedId()
            if IsPedJumping(ped) and not IsPedInAnyVehicle(ped, false) and not IsPedRagdoll(ped) then
                local startZ = GetEntityCoords(ped).z
                local peak = startZ
                while IsPedJumping(ped) do
                    Wait(50)
                    local z = GetEntityCoords(ped).z
                    if z > peak then peak = z end
                end
                local height = peak - startZ
                if height > HSC.value('SuperJump') then
                    HSC.flag('SuperJump', ('%.1f m'):format(height))
                else HSC.decay('SuperJump') end
            end
        end
    end
end)

-- Unknown resources (injected menus)
CreateThread(function()
    while true do
        Wait(60000)
        if HSC.token and check('Injection') then
            local list = {}
            for i = 0, GetNumResources() - 1 do
                local r = GetResourceByFindIndex(i)
                if r and r:sub(1, 1) ~= '_' and GetResourceState(r) == 'started' then list[#list + 1] = r end
            end
            TriggerServerEvent('heroshield:resources', HSC.token, list)
        end
    end
end)
