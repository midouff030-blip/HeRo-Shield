local function unsafe(ped)
    return IsPedInAnyVehicle(ped, false) or IsPedFalling(ped) or IsPedRagdoll(ped)
        or IsPedInParachuteFreeFall(ped) or GetPedParachuteState(ped) > 0
        or IsEntityAttached(ped) or IsPlayerSwitchInProgress() or IsEntityDead(ped)
        or IsPedSwimmingUnderWater(ped) or IsCutsceneActive() or IsScreenFadedOut()
end

local badWeapons = {}
for _, w in ipairs(Config.BlacklistedWeapons) do badWeapons[GetHashKey(w)] = w end

-- Main checks (every second)
CreateThread(function()
    local lastPos
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)

        if HSC.active() then
            local ply = PlayerId()
            local safe = not unsafe(ped)

            if HSC.det('GodMode') then
                if GetPlayerInvincible(ply) or GetPlayerInvincible_2(ply) or not GetEntityCanBeDamaged(ped) then
                    HSC.flag('GodMode', 'invincible')
                else HSC.decay('GodMode') end
            end

            if HSC.det('SpeedHack') and safe then
                local speed = GetEntitySpeed(ped)
                if speed > HSC.value('SpeedHack') then
                    HSC.flag('SpeedHack', ('%.1f m/s'):format(speed))
                else HSC.decay('SpeedHack') end
            end

            if HSC.det('NoClip') and lastPos and safe then
                local dist = #(pos - lastPos)
                if dist > HSC.value('NoClip') then
                    HSC.flag('NoClip', ('%.0f m/s'):format(dist))
                else HSC.decay('NoClip') end
            end

            if HSC.det('Invisible') then
                if not IsEntityVisible(ped) and not IsCutsceneActive() and not IsPlayerSwitchInProgress() then
                    HSC.flag('Invisible', 'invisible ped')
                else HSC.decay('Invisible') end
            end

            if HSC.det('Spectate') and NetworkIsInSpectatorMode() then
                HSC.flag('Spectate', 'spectator mode')
            end

            if HSC.det('BlacklistedWeapon') then
                local w = GetSelectedPedWeapon(ped)
                if badWeapons[w] then
                    RemoveWeaponFromPed(ped, w)
                    HSC.flag('BlacklistedWeapon', badWeapons[w])
                end
            end
        end

        lastPos = pos
    end
end)

-- Super jump
CreateThread(function()
    while true do
        Wait(250)
        if HSC.active() and HSC.det('SuperJump') then
            local ped = PlayerPedId()
            if IsPedJumping(ped) and not IsPedInAnyVehicle(ped, false) then
                local startZ = GetEntityCoords(ped).z
                local peak = startZ
                while IsPedJumping(ped) do
                    Wait(50)
                    local z = GetEntityCoords(ped).z
                    if z > peak then peak = z end
                end
                local height = peak - startZ
                if height > HSC.value('SuperJump') then
                    HSC.flag('SuperJump', ('%.1f m'):format(height))
                else HSC.decay('SuperJump') end
            end
        end
    end
end)

-- Unknown resources
CreateThread(function()
    while true do
        Wait(60000)
        if HSC.active() and HSC.det('Injection') and HSC.token then
            local list = {}
            for i = 0, GetNumResources() - 1 do
                local r = GetResourceByFindIndex(i)
                if r and GetResourceState(r) == 'started' then list[#list + 1] = r end
            end
            TriggerServerEvent('heroshield:resources', HSC.token, list)
        end
    end
end)
